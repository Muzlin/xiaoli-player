import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/platform_service.dart';
import 'live_page.dart';

/// 把文本里的网址变成可点链接(在 app 内/外部浏览器打开)。
final _urlRe = RegExp(r'(https?://[^\s]+)');
Widget _linkifyText(String text, Color color) {
  if (!_urlRe.hasMatch(text)) {
    return Text(text, style: TextStyle(color: color));
  }
  final spans = <InlineSpan>[];
  var last = 0;
  for (final m in _urlRe.allMatches(text)) {
    if (m.start > last) {
      spans.add(TextSpan(text: text.substring(last, m.start)));
    }
    final url = m.group(0)!;
    spans.add(TextSpan(
      text: url,
      style: const TextStyle(
          decoration: TextDecoration.underline, fontWeight: FontWeight.w600),
      recognizer: TapGestureRecognizer()
        ..onTap = () {
          final uri = Uri.tryParse(url);
          if (uri != null) {
            launchUrl(uri, mode: LaunchMode.externalApplication);
          }
        },
    ));
    last = m.end;
  }
  if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
  return Text.rich(TextSpan(style: TextStyle(color: color), children: spans));
}

/// 聊天记录搜索：把 text 里匹配 query(大小写不敏感)的片段用黄底高亮，用于搜索结果展示。
/// 会话内搜索(_ChatPage/_GroupChatPage)和聚合搜索(_ChatSearchAllPage)共用。
Widget _highlightMatch(String text, String query,
    {TextStyle? style, int maxLines = 2}) {
  if (query.isEmpty) {
    return Text(text,
        style: style, maxLines: maxLines, overflow: TextOverflow.ellipsis);
  }
  final lowerText = text.toLowerCase();
  final lowerQ = query.toLowerCase();
  final spans = <InlineSpan>[];
  var start = 0;
  while (true) {
    final idx = lowerText.indexOf(lowerQ, start);
    if (idx < 0) {
      spans.add(TextSpan(text: text.substring(start)));
      break;
    }
    if (idx > start) spans.add(TextSpan(text: text.substring(start, idx)));
    spans.add(TextSpan(
      text: text.substring(idx, idx + query.length),
      style: const TextStyle(
          backgroundColor: Color(0xFFFFE082), fontWeight: FontWeight.w700),
    ));
    start = idx + query.length;
  }
  return Text.rich(TextSpan(style: style, children: spans),
      maxLines: maxLines, overflow: TextOverflow.ellipsis);
}

/// 聊天记录搜索结果里的相对时间(如"3分钟前"/"2天前")。
String _fmtAgo(int ts) {
  if (ts <= 0) return '';
  final d =
      DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ts * 1000));
  if (d.inMinutes < 1) return '刚刚';
  if (d.inHours < 1) return '${d.inMinutes}分钟前';
  if (d.inDays < 1) return '${d.inHours}小时前';
  return '${d.inDays}天前';
}

/// 会话置顶 / 消息免打扰：本地缓存 + 服务端为准。key='dm:对方uid' / 'grp:群id'，
/// 与 activeChatKey/草稿箱同一套命名。
/// 实际数据挂在 PlatformService.pinnedKeys/mutedKeys 上（公共类，home_shell.dart 弹系统通知前
/// 也要读它判断免打扰——这个 _ChatPrefs 类本身是本文件私有的，跨文件访问不到）。
/// dmList()/groupList() 每次请求都会用服务端返回的 pinned_keys/muted_keys 整体覆盖刷新，
/// 这里只是加一层本地持久化(冷启动/离线兜底显示)，togglePin/toggleMute 时顺带调 /prefs-set 云同步。
class _ChatPrefs {
  static Set<String> get pinned => PlatformService.pinnedKeys;
  static Set<String> get muted => PlatformService.mutedKeys;
  static bool _loaded = false;

  static Future<void> ensure() async {
    if (_loaded) return;
    final p = await SharedPreferences.getInstance();
    PlatformService.pinnedKeys = (p.getStringList('chat_pinned') ?? []).toSet();
    PlatformService.mutedKeys = (p.getStringList('chat_muted') ?? []).toSet();
    _loaded = true;
  }

  static Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('chat_pinned', PlatformService.pinnedKeys.toList());
    await p.setStringList('chat_muted', PlatformService.mutedKeys.toList());
  }

  /// dm-list/group-list 每次都会把服务端最新的 pinned_keys/muted_keys 覆盖进
  /// PlatformService.pinnedKeys/mutedKeys；这里把那份结果落盘，供下次冷启动/离线时兜底。
  static Future<void> persistFromServer() => _persist();

  static Future<void> togglePin(String k) async {
    final on = !pinned.contains(k);
    on ? pinned.add(k) : pinned.remove(k);
    await _persist();
    await PlatformService.prefsSet(key: k, kind: 'pin', on: on);
  }

  static Future<void> toggleMute(String k) async {
    final on = !muted.contains(k);
    on ? muted.add(k) : muted.remove(k);
    await _persist();
    await PlatformService.prefsSet(key: k, kind: 'mute', on: on);
  }

  /// 置顶的排前面（保持各自原顺序）。
  static List<Map<String, dynamic>> sort(
      List<Map<String, dynamic>> list, String Function(Map<String, dynamic>) key) {
    final pin = list.where((c) => pinned.contains(key(c))).toList();
    final rest = list.where((c) => !pinned.contains(key(c))).toList();
    return [...pin, ...rest];
  }
}

/// 聊天草稿箱（纯本地）。key='dm:对方uid' / 'grp:群id'，与 activeChatKey 同一套命名。
/// 未发送的文字防抖写入，下次进入对应会话自动填回；发送成功后清空。
class _ChatDraft {
  static const _prefix = 'chat_draft_';

  static Future<String> load(String key) async {
    final p = await SharedPreferences.getInstance();
    return p.getString('$_prefix$key') ?? '';
  }

  static Future<void> save(String key, String text) async {
    final p = await SharedPreferences.getInstance();
    if (text.isEmpty) {
      await p.remove('$_prefix$key');
    } else {
      await p.setString('$_prefix$key', text);
    }
  }

  static Future<void> clear(String key) async {
    final p = await SharedPreferences.getInstance();
    await p.remove('$_prefix$key');
  }
}

/// 群公告已读进度（纯本地）。key='ann_seen_群id' -> 已读到的 announcement_ts。
/// 用于群列表/群聊入口判断"有没有新公告"。
class _AnnouncementPrefs {
  static const _prefix = 'ann_seen_';
  static Map<String, int> _seen = {};
  static bool _loaded = false;

  static Future<void> ensure() async {
    if (_loaded) return;
    final p = await SharedPreferences.getInstance();
    _seen = {
      for (final k in p.getKeys())
        if (k.startsWith(_prefix)) k.substring(_prefix.length): (p.getInt(k) ?? 0)
    };
    _loaded = true;
  }

  /// 公告非空 且 更新时间晚于本地已读记录 -> 算"新公告"。
  static bool isNew(String gid, int announcementTs) =>
      announcementTs > 0 && announcementTs > (_seen[gid] ?? 0);

  static Future<void> markSeen(String gid, int announcementTs) async {
    if (announcementTs <= (_seen[gid] ?? 0)) return;
    _seen[gid] = announcementTs;
    final p = await SharedPreferences.getInstance();
    await p.setInt('$_prefix$gid', announcementTs);
  }
}

/// 消息中心：私信 + 群聊。onPlayVideo 用于点开"推荐视频"卡片直接播。
class MessagesPage extends StatefulWidget {
  final void Function(String id, String title) onPlayVideo;
  const MessagesPage({super.key, required this.onPlayVideo});
  @override
  State<MessagesPage> createState() => _MessagesPageState();
}

class _MessagesPageState extends State<MessagesPage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('消息'),
          actions: [
            IconButton(
              icon: const Icon(Icons.search),
              tooltip: '搜索全部聊天',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) =>
                      _ChatSearchAllPage(onPlayVideo: widget.onPlayVideo))),
            ),
            IconButton(
              icon: const Icon(Icons.camera_outlined),
              tooltip: '朋友圈',
              onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                      builder: (_) =>
                          MomentsPage(onPlayVideo: widget.onPlayVideo))),
            ),
            IconButton(
              icon: const Icon(Icons.smart_toy_outlined),
              tooltip: '机器人',
              onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const BotPage())),
            ),
            PopupMenuButton<String>(
              tooltip: '更多',
              onSelected: (v) async {
                if (v == 'blacklist') {
                  Navigator.of(context).push(MaterialPageRoute<void>(
                      builder: (_) => const _BlacklistPage()));
                }
                if (v == 'test') {
                  final nowTest = await PlatformService.onTestAccount();
                  await PlatformService.switchTestAccount();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(nowTest
                            ? '已切回主账号'
                            : '已切到测试账号（再点一次切回）')));
                    Navigator.of(context).pop();
                  }
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(
                    value: 'blacklist', child: Text('黑名单管理')),
                const PopupMenuItem(
                    value: 'test', child: Text('切换测试账号')),
              ],
            ),
          ],
          bottom: const TabBar(tabs: [
            Tab(text: '私信', icon: Icon(Icons.chat_bubble_outline)),
            Tab(text: '群聊', icon: Icon(Icons.groups_outlined)),
          ]),
        ),
        body: TabBarView(children: [
          _DmTab(onPlayVideo: widget.onPlayVideo),
          _GroupTab(onPlayVideo: widget.onPlayVideo),
        ]),
      ),
    );
  }
}

// ============ 聚合搜索：搜索全部聊天(私信+群聊) ============
class _ChatSearchAllPage extends StatefulWidget {
  final void Function(String id, String title) onPlayVideo;
  const _ChatSearchAllPage({required this.onPlayVideo});
  @override
  State<_ChatSearchAllPage> createState() => _ChatSearchAllPageState();
}

class _ChatSearchAllPageState extends State<_ChatSearchAllPage> {
  final _ctrl = TextEditingController();
  Timer? _debounce;
  bool _searching = false;
  List<Map<String, dynamic>> _results = [];

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () => _run(v));
  }

  Future<void> _run(String q) async {
    final query = q.trim();
    if (query.isEmpty) {
      if (mounted) setState(() => _results = []);
      return;
    }
    if (mounted) setState(() => _searching = true);
    final r = await PlatformService.chatSearchAll(query);
    if (!mounted) return;
    setState(() {
      _searching = false;
      _results = r;
    });
  }

  void _openResult(Map<String, dynamic> r) {
    final scope = '${r['scope'] ?? 'dm'}';
    final target = '${r['target'] ?? ''}';
    if (target.isEmpty) return;
    if (scope == 'group') {
      Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) =>
              _GroupChatPage(gid: target, onPlayVideo: widget.onPlayVideo)));
    } else {
      Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => _ChatPage(
              peer: target,
              peerNick: '${r['name'] ?? target}',
              onPlayVideo: widget.onPlayVideo)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _ctrl.text.trim();
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          autofocus: true,
          decoration: const InputDecoration(
              hintText: '搜索全部私信和群聊', border: InputBorder.none),
          onChanged: _onChanged,
        ),
      ),
      body: _searching
          ? const Center(child: CircularProgressIndicator())
          : q.isEmpty
              ? const Center(
                  child: Text('输入关键词搜索所有会话的聊天记录',
                      style: TextStyle(color: Colors.black38)))
              : _results.isEmpty
                  ? const Center(
                      child: Text('没有找到相关消息',
                          style: TextStyle(color: Colors.black38)))
                  : ListView.separated(
                      itemCount: _results.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final r = _results[i];
                        final scope = '${r['scope'] ?? 'dm'}';
                        final name = '${r['name'] ?? ''}';
                        return ListTile(
                          leading: Icon(scope == 'group'
                              ? Icons.groups_outlined
                              : Icons.person_outline),
                          title: Text('来自「$name」的会话',
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.black54)),
                          subtitle: _highlightMatch('${r['text'] ?? ''}', q,
                              maxLines: 1),
                          trailing: Text(
                              _fmtAgo((r['ts'] as num?)?.toInt() ?? 0),
                              style: const TextStyle(
                                  fontSize: 11, color: Colors.black38)),
                          onTap: () => _openResult(r),
                        );
                      },
                    ),
    );
  }
}

// ============ 黑名单管理 ============
class _BlacklistPage extends StatefulWidget {
  const _BlacklistPage();
  @override
  State<_BlacklistPage> createState() => _BlacklistPageState();
}

class _BlacklistPageState extends State<_BlacklistPage> {
  bool _loading = true;
  List<Map<String, dynamic>> _users = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final u = await PlatformService.blacklistList();
    if (mounted) setState(() {
      _users = u;
      _loading = false;
    });
  }

  Future<void> _remove(Map<String, dynamic> u) async {
    final target = '${u['uid'] ?? ''}';
    if (target.isEmpty) return;
    final ok = await PlatformService.blacklistSet(target: target, on: false);
    if (!mounted) return;
    if (ok) {
      _snack(context, '已取消拉黑「${u['nick'] ?? target}」');
      _load();
    } else {
      _snack(context, '操作失败');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('黑名单管理')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _users.isEmpty
              ? const Center(
                  child: Text('还没有拉黑任何人',
                      style: TextStyle(color: Colors.black38)))
              : ListView.separated(
                  itemCount: _users.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final u = _users[i];
                    return ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.person)),
                      title: Text('${u['nick'] ?? u['uid'] ?? ''}'),
                      trailing: OutlinedButton(
                        onPressed: () => _remove(u),
                        child: const Text('移除'),
                      ),
                    );
                  },
                ),
    );
  }
}

// ============ 私信 ============
class _DmTab extends StatefulWidget {
  final void Function(String id, String title) onPlayVideo;
  const _DmTab({required this.onPlayVideo});
  @override
  State<_DmTab> createState() => _DmTabState();
}

class _DmTabState extends State<_DmTab> {
  bool _loading = true;
  List<Map<String, dynamic>> _convs = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await _ChatPrefs.ensure();
    final c = await PlatformService.dmList(); // 顺带把 pinned_keys/muted_keys 刷进本地缓存
    await _ChatPrefs.persistFromServer();
    await PlatformService.blacklistList(); // 顺带把 blacklistedUids 刷进本地缓存
    if (mounted) setState(() {
      _convs = _ChatPrefs.sort(c, (x) => 'dm:${x['peer']}');
      _loading = false;
    });
  }

  Future<void> _convMenu(String key) async {
    final pinned = _ChatPrefs.pinned.contains(key);
    final muted = _ChatPrefs.muted.contains(key);
    final peer = key.startsWith('dm:') ? key.substring(3) : '';
    final blocked = PlatformService.blacklistedUids.contains(peer);
    final v = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined),
              title: Text(pinned ? '取消置顶' : '置顶会话'),
              onTap: () => Navigator.pop(context, 'pin')),
          ListTile(
              leading: Icon(
                  muted ? Icons.notifications_off : Icons.notifications_off_outlined),
              title: Text(muted ? '取消免打扰' : '消息免打扰'),
              onTap: () => Navigator.pop(context, 'mute')),
          ListTile(
              leading: Icon(blocked ? Icons.block : Icons.block_outlined),
              title: Text(blocked ? '取消拉黑' : '拉黑'),
              onTap: () => Navigator.pop(context, 'block')),
        ]),
      ),
    );
    if (v == 'pin') await _ChatPrefs.togglePin(key);
    if (v == 'mute') await _ChatPrefs.toggleMute(key);
    if (v == 'block' && peer.isNotEmpty) {
      await PlatformService.blacklistSet(target: peer, on: !blocked);
    }
    _load();
  }

  Future<void> _newChat() async {
    final picked = await _pickUser(context);
    if (picked == null || !mounted) return;
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => _ChatPage(
        peer: picked['uid'] as String,
        peerNick: picked['nick'] as String,
        onPlayVideo: widget.onPlayVideo,
      ),
    ));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: _newChat,
        tooltip: '发起私信',
        child: const Icon(Icons.edit),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _convs.isEmpty
              ? const Center(
                  child: Text('还没有私信，点右下角找人聊~',
                      style: TextStyle(color: Colors.black38)))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    itemCount: _convs.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final c = _convs[i];
                      final key = 'dm:${c['peer']}';
                      final pinned = _ChatPrefs.pinned.contains(key);
                      final muted = _ChatPrefs.muted.contains(key);
                      return ListTile(
                        tileColor:
                            pinned ? const Color(0x0A000000) : null,
                        leading: const CircleAvatar(
                            child: Icon(Icons.person)),
                        title: Row(children: [
                          Flexible(child: Text('${c['peer_nick'] ?? ''}')),
                          if (muted)
                            const Padding(
                              padding: EdgeInsets.only(left: 6),
                              child: Icon(Icons.notifications_off,
                                  size: 14, color: Colors.black38),
                            ),
                        ]),
                        subtitle: Text('${c['last'] ?? ''}',
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: pinned
                            ? const Icon(Icons.push_pin,
                                size: 14, color: Colors.black38)
                            : null,
                        onLongPress: () => _convMenu(key),
                        onTap: () async {
                          await Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                  builder: (_) => _ChatPage(
                                        peer: c['peer'] as String,
                                        peerNick: '${c['peer_nick'] ?? ''}',
                                        onPlayVideo: widget.onPlayVideo,
                                      )));
                          _load();
                        },
                      );
                    },
                  ),
                ),
    );
  }
}

// ============ 群聊列表 ============
class _GroupTab extends StatefulWidget {
  final void Function(String id, String title) onPlayVideo;
  const _GroupTab({required this.onPlayVideo});
  @override
  State<_GroupTab> createState() => _GroupTabState();
}

class _GroupTabState extends State<_GroupTab> {
  bool _loading = true;
  List<Map<String, dynamic>> _groups = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await _ChatPrefs.ensure();
    await _AnnouncementPrefs.ensure();
    final g = await PlatformService.groupList(); // 顺带把 pinned_keys/muted_keys 刷进本地缓存
    await _ChatPrefs.persistFromServer();
    if (mounted) setState(() {
      _groups = _ChatPrefs.sort(g, (x) => 'grp:${x['gid']}');
      _loading = false;
    });
  }

  Future<void> _groupMenu(String key) async {
    final pinned = _ChatPrefs.pinned.contains(key);
    final muted = _ChatPrefs.muted.contains(key);
    final v = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined),
              title: Text(pinned ? '取消置顶' : '置顶群聊'),
              onTap: () => Navigator.pop(context, 'pin')),
          ListTile(
              leading: Icon(muted
                  ? Icons.notifications_off
                  : Icons.notifications_off_outlined),
              title: Text(muted ? '取消免打扰' : '消息免打扰'),
              onTap: () => Navigator.pop(context, 'mute')),
        ]),
      ),
    );
    if (v == 'pin') await _ChatPrefs.togglePin(key);
    if (v == 'mute') await _ChatPrefs.toggleMute(key);
    _load();
  }

  Future<void> _createGroup() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('建群'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLength: 30,
          decoration: const InputDecoration(hintText: '群名称'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('创建')),
        ],
      ),
    );
    if (ok != true) return;
    final name = ctrl.text.trim();
    if (name.isEmpty) return;
    final d = await PlatformService.groupCreate(name);
    if (d != null && d['ok'] == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: _createGroup,
        tooltip: '建群',
        child: const Icon(Icons.group_add),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _groups.isEmpty
              ? const Center(
                  child: Text('还没有群，点右下角建一个~',
                      style: TextStyle(color: Colors.black38)))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    itemCount: _groups.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final g = _groups[i];
                      final role = '${g['role']}';
                      final key = '${g['gid']}'; // 原始 gid：给 _AnnouncementPrefs/群聊页跳转用
                      final convKey = 'grp:$key'; // 前缀过的 conv_key：给 _ChatPrefs 置顶/免打扰用
                      final pinned = _ChatPrefs.pinned.contains(convKey);
                      final muted = _ChatPrefs.muted.contains(convKey);
                      final annText = '${g['announcement'] ?? ''}';
                      final annTs = (g['announcement_ts'] as num?)?.toInt() ?? 0;
                      final hasNewAnn =
                          annText.isNotEmpty && _AnnouncementPrefs.isNew(key, annTs);
                      return ListTile(
                        tileColor:
                            pinned ? const Color(0x0A000000) : null,
                        leading: const CircleAvatar(
                            child: Icon(Icons.groups)),
                        title: Row(children: [
                          Flexible(child: Text('${g['name'] ?? ''}')),
                          if (hasNewAnn)
                            Container(
                              margin: const EdgeInsets.only(left: 6),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 1),
                              decoration: BoxDecoration(
                                  color: const Color(0xFFE3A93B),
                                  borderRadius: BorderRadius.circular(8)),
                              child: const Text('新公告',
                                  style: TextStyle(
                                      fontSize: 10, color: Colors.white)),
                            ),
                          if (muted)
                            const Padding(
                              padding: EdgeInsets.only(left: 6),
                              child: Icon(Icons.notifications_off,
                                  size: 14, color: Colors.black38),
                            ),
                        ]),
                        subtitle: Text(
                            '${g['count']} 人${role == 'owner' ? ' · 群主' : role == 'admin' ? ' · 管理' : ''}${g['no_leave'] == true ? ' · 禁退' : ''}'),
                        trailing: pinned
                            ? const Icon(Icons.push_pin,
                                size: 14, color: Colors.black38)
                            : null,
                        onLongPress: () => _groupMenu(convKey),
                        onTap: () async {
                          await Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                  builder: (_) => _GroupChatPage(
                                        gid: g['gid'] as String,
                                        onPlayVideo: widget.onPlayVideo,
                                      )));
                          _load();
                        },
                      );
                    },
                  ),
                ),
    );
  }
}

// ============ 私信聊天 ============
class _ChatPage extends StatefulWidget {
  final String peer;
  final String peerNick;
  final void Function(String id, String title) onPlayVideo;
  const _ChatPage(
      {required this.peer, required this.peerNick, required this.onPlayVideo});
  @override
  State<_ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<_ChatPage> {
  final _ctrl = TextEditingController();
  List<Map<String, dynamic>> _msgs = [];
  String? _myUid;
  Timer? _draftTimer;
  String get _draftKey => 'dm:${widget.peer}';

  // 本会话搜索：搜索框防抖调用带 q 的 dmMsgs，命中结果点击后跳转/定位到该消息附近。
  bool _searchMode = false;
  final _searchCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final Map<String, GlobalKey> _msgKeys = {};
  Timer? _searchDebounce;
  bool _searching = false;
  List<Map<String, dynamic>> _searchResults = [];
  String? _highlightMid;

  // 消息多选：长按菜单点"多选"进入，勾选后底部栏可批量转发/批量删除(=批量撤回自己的消息)。
  bool _selectMode = false;
  final Set<String> _selectedMids = {};

  @override
  void initState() {
    super.initState();
    PlatformService.activeChatKey = 'dm:${widget.peer}'; // 正在看，别给这会话弹通知
    PlatformService.walletUid()
        .then((u) => mounted ? setState(() => _myUid = u) : null);
    // 刷新"我是否已拉黑对方"，据此决定 _ChatInput 是否隐藏发送框。
    PlatformService.blacklistList().then((_) => mounted ? setState(() {}) : null);
    _load();
    _ctrl.addListener(_onDraftChanged);
    _ChatDraft.load(_draftKey).then((t) {
      if (mounted && t.isNotEmpty) {
        _ctrl.text = t;
        _ctrl.selection =
            TextSelection.fromPosition(TextPosition(offset: _ctrl.text.length));
      }
    });
  }

  void _onDraftChanged() {
    _draftTimer?.cancel();
    _draftTimer = Timer(const Duration(milliseconds: 500),
        () => _ChatDraft.save(_draftKey, _ctrl.text));
  }

  @override
  void dispose() {
    if (PlatformService.activeChatKey == 'dm:${widget.peer}') {
      PlatformService.activeChatKey = null;
    }
    _draftTimer?.cancel();
    _ChatDraft.save(_draftKey, _ctrl.text); // 兜底落盘
    _ctrl.removeListener(_onDraftChanged);
    _searchDebounce?.cancel();
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _toggleSearch() {
    setState(() {
      _searchMode = !_searchMode;
      if (!_searchMode) {
        _searchDebounce?.cancel();
        _searchCtrl.clear();
        _searchResults = [];
        _searching = false;
      }
    });
  }

  void _onSearchChanged(String v) {
    _searchDebounce?.cancel();
    _searchDebounce =
        Timer(const Duration(milliseconds: 350), () => _runSearch(v));
  }

  Future<void> _runSearch(String q) async {
    final query = q.trim();
    if (query.isEmpty) {
      if (mounted) setState(() => _searchResults = []);
      return;
    }
    if (mounted) setState(() => _searching = true);
    final d = await PlatformService.dmMsgs(widget.peer, q: query);
    if (!mounted) return;
    setState(() {
      _searching = false;
      _searchResults = ((d?['msgs'] as List?) ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    });
  }

  // 跳转/定位到该消息附近：先按索引比例粗定位，再等这一帧建好后用 ensureVisible 精定位，
  // 并临时高亮几秒方便肉眼找到（消息数量有限，全量已加载，不做分页翻页）。
  Future<void> _jumpToMsg(String mid) async {
    if (mid.isEmpty) return;
    setState(() {
      _searchMode = false;
      _highlightMid = mid;
    });
    final idx = _msgs.indexWhere((m) => m['mid'] == mid);
    if (idx < 0) return;
    await Future.delayed(const Duration(milliseconds: 60));
    if (!mounted) return;
    if (_scrollCtrl.hasClients && _msgs.length > 1) {
      final frac = idx / (_msgs.length - 1);
      final target = (_scrollCtrl.position.maxScrollExtent * frac)
          .clamp(0.0, _scrollCtrl.position.maxScrollExtent);
      _scrollCtrl.jumpTo(target);
    }
    await Future.delayed(const Duration(milliseconds: 120));
    final ctx = _msgKeys[mid]?.currentContext;
    if (ctx != null && mounted) {
      await Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 250), alignment: 0.5);
    }
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted && _highlightMid == mid) setState(() => _highlightMid = null);
    });
  }

  Widget _buildSearchResults() {
    if (_searching) return const Center(child: CircularProgressIndicator());
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) {
      return const Center(
          child: Text('输入关键词搜索本会话消息', style: TextStyle(color: Colors.black38)));
    }
    if (_searchResults.isEmpty) {
      return const Center(
          child: Text('没有找到相关消息', style: TextStyle(color: Colors.black38)));
    }
    return ListView.separated(
      itemCount: _searchResults.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) {
        final m = _searchResults[i];
        final mine = m['from'] == _myUid;
        return ListTile(
          leading: Icon(mine ? Icons.arrow_upward : Icons.arrow_downward,
              size: 18, color: Colors.black45),
          title: _highlightMatch('${m['text'] ?? ''}', q),
          subtitle: Text(_fmtAgo((m['ts'] as num?)?.toInt() ?? 0),
              style: const TextStyle(fontSize: 11, color: Colors.black38)),
          onTap: () => _jumpToMsg('${m['mid'] ?? ''}'),
        );
      },
    );
  }

  Future<void> _load() async {
    final d = await PlatformService.dmMsgs(widget.peer);
    if (d != null && mounted) {
      setState(() => _msgs = ((d['msgs'] as List?) ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList());
    }
  }

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    _ctrl.clear();
    _draftTimer?.cancel();
    await _ChatDraft.clear(_draftKey);
    final ok = await PlatformService.dmSend(widget.peer, text: t);
    if (ok) _load();
  }

  Future<void> _recommend() async {
    final v = await _pickVideo(context);
    if (v == null) return;
    final ok = await PlatformService.dmSend(widget.peer,
        vid: v['id'] as String, title: v['title'] as String);
    if (ok) _load();
  }

  // 在私聊里发红包（=转账 + 一条🧧消息，对方余额到账）。
  Future<void> _redpacket() async {
    var amount = 8;
    final msgCtrl = TextEditingController(text: '恭喜发财，大吉大利');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          backgroundColor: const Color(0xFFC0392B),
          title: const Text('🧧 发红包', style: TextStyle(color: Color(0xFFFFE2A8))),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Wrap(spacing: 8, children: [
              for (final a in [6, 8, 18, 66, 88])
                ChoiceChip(
                  label: Text('$a'),
                  selected: amount == a,
                  selectedColor: const Color(0xFFFFD24A),
                  onSelected: (_) => setD(() => amount = a),
                ),
            ]),
            const SizedBox(height: 10),
            TextField(
              controller: msgCtrl,
              maxLength: 40,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: '写句祝福…',
                hintStyle: TextStyle(color: Colors.white54),
                counterStyle: TextStyle(color: Colors.white54),
              ),
            ),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child:
                    const Text('取消', style: TextStyle(color: Colors.white70))),
            FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFFFD24A),
                    foregroundColor: const Color(0xFF7A1F18)),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('塞钱进红包')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final d = await PlatformService.chatPacket(
        scope: 'dm',
        target: widget.peer,
        ptype: 'redpacket',
        amount: amount,
        msg: msgCtrl.text.trim());
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _snack(context, '🧧 红包已发出，等对方领取');
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '发红包失败'}');
    }
  }

  Future<void> _sendCard() async {
    final picked = await _pickUser(context);
    if (picked == null) return;
    final ok =
        await PlatformService.dmSend(widget.peer, card: picked['uid'] as String);
    if (ok) _load();
  }

  void _openCard(String uid, String nick) {
    if (uid.isEmpty) return;
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => _ChatPage(
          peer: uid, peerNick: nick, onPlayVideo: widget.onPlayVideo),
    ));
  }

  Future<void> _transfer() async {
    final amt = await _askAmount(context, '转账给 ${widget.peerNick}');
    if (amt == null || amt <= 0) return;
    final d = await PlatformService.chatPacket(
        scope: 'dm', target: widget.peer, ptype: 'transfer', amount: amt);
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _snack(context, '已发出转账，等对方收款');
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '转账失败'}');
    }
  }

  Future<Map<String, dynamic>?> _grabPacket(String pid) async {
    final d = await PlatformService.packetGrab(pid);
    if (mounted) _load();
    return d;
  }

  // 本地乐观更新：用服务端返回的最新 msg 原地替换列表里对应 mid 的那条，不等下次轮询。
  void _applyMsgPatch(String mid, Map<String, dynamic>? newMsg) {
    if (newMsg == null || !mounted) return;
    setState(() {
      final i = _msgs.indexWhere((x) => x['mid'] == mid);
      if (i != -1) _msgs[i] = Map<String, dynamic>.from(newMsg);
    });
  }

  Future<void> _recallMsg(Map<String, dynamic> m) async {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty) return;
    final d =
        await PlatformService.msgRecall(scope: 'dm', target: widget.peer, mid: mid);
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _applyMsgPatch(mid, d['msg'] as Map<String, dynamic>?);
    } else {
      _snack(context, '${d?['error'] ?? '撤回失败'}');
    }
  }

  Future<void> _editMsg(Map<String, dynamic> m, String text) async {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty) return;
    final d = await PlatformService.msgEdit(
        scope: 'dm', target: widget.peer, mid: mid, text: text);
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _applyMsgPatch(mid, d['msg'] as Map<String, dynamic>?);
    } else {
      _snack(context, '${d?['error'] ?? '编辑失败'}');
    }
  }

  // 表情包面板：选中"我的收藏"直接发；精品表情要消耗积分，发前二次确认。
  Future<void> _openStickerPicker() async {
    final picked = await _pickSticker(context);
    if (picked == null || !mounted) return;
    final cost = (picked['cost'] as num?)?.toInt() ?? 0;
    if (cost > 0) {
      final ok = await _confirm(context, '发送精品表情', '将消耗 $cost 兑换币，确定发送吗？');
      if (!ok || !mounted) return;
    }
    final d = await PlatformService.sendSticker(
        scope: 'dm', target: widget.peer, stickerId: '${picked['id']}');
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '发送失败'}');
    }
  }

  // 点"XX 正在直播"提醒卡片：进直播间(若已下播，LiveRoomPage 会自己提示"直播已结束")。
  void _openLiveAlert(Map<String, dynamic> m) {
    final lid = '${m['lid'] ?? ''}';
    if (lid.isEmpty) return;
    Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => LiveRoomPage(
            lid: lid,
            isHost: false,
            title: '${m['live_nick'] ?? ''}的直播',
            onPlayVideo: widget.onPlayVideo)));
  }

  void _enterSelectMode(Map<String, dynamic> m) {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty) return;
    setState(() {
      _selectMode = true;
      _selectedMids
        ..clear()
        ..add(mid);
    });
  }

  void _toggleSelect(String mid) {
    setState(() {
      if (!_selectedMids.remove(mid)) _selectedMids.add(mid);
    });
  }

  void _exitSelectMode() {
    setState(() {
      _selectMode = false;
      _selectedMids.clear();
    });
  }

  Future<void> _batchForwardSelected() async {
    final msgs =
        _msgs.where((m) => _selectedMids.contains('${m['mid'] ?? ''}')).toList();
    await _forwardMessages(context, msgs);
    if (mounted) _exitSelectMode();
  }

  // 批量删除=批量撤回自己的消息，超时/非本人的会被服务端跳过，跳过原因合并成一句提示。
  Future<void> _batchDelete() async {
    if (_selectedMids.isEmpty) return;
    final d = await PlatformService.msgRecallBatch(
        scope: 'dm', target: widget.peer, mids: _selectedMids.toList());
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      final revoked = ((d['revoked'] as List?) ?? const []).length;
      final skipped = (d['skipped'] as List?) ?? const [];
      final timeoutN =
          skipped.where((s) => s is Map && s['reason'] == '超时').length;
      final otherN = skipped.length - timeoutN;
      var msg = '已撤回 $revoked 条';
      if (timeoutN > 0) msg += '，$timeoutN条已超时未撤回';
      if (otherN > 0) msg += '，$otherN条无法撤回';
      _snack(context, msg);
      _load();
      _exitSelectMode();
    } else {
      _snack(context, '${d?['error'] ?? '批量撤回失败'}');
    }
  }

  // 多选模式下的底部操作栏：转发(N) / 删除(N)。
  Widget _buildSelectBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFE0E0E0))),
        ),
        child: Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _selectedMids.isEmpty ? null : _batchForwardSelected,
              icon: const Icon(Icons.forward, size: 18),
              label: Text('转发(${_selectedMids.length})'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent),
              onPressed: _selectedMids.isEmpty ? null : _batchDelete,
              icon: const Icon(Icons.delete_outline, size: 18),
              label: Text('删除(${_selectedMids.length})'),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDEDED),
      appBar: AppBar(
          leading: _selectMode
              ? IconButton(
                  icon: const Icon(Icons.close), onPressed: _exitSelectMode)
              : null,
          title: _selectMode
              ? Text('已选择 ${_selectedMids.length} 条')
              : _searchMode
              ? TextField(
                  controller: _searchCtrl,
                  autofocus: true,
                  style: const TextStyle(color: Colors.black87),
                  decoration: const InputDecoration(
                      hintText: '搜索聊天记录',
                      hintStyle: TextStyle(color: Colors.black38),
                      border: InputBorder.none),
                  onChanged: _onSearchChanged)
              : GestureDetector(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                      builder: (_) => ProfilePage(
                          uid: widget.peer, onPlayVideo: widget.onPlayVideo))),
                  child: Text(widget.peerNick)),
          backgroundColor: const Color(0xFFEDEDED),
          foregroundColor: Colors.black87,
          elevation: 0,
          actions: _selectMode
              ? []
              : [
                  IconButton(
                    icon: Icon(_searchMode ? Icons.close : Icons.search),
                    tooltip: _searchMode ? '取消搜索' : '搜索聊天记录',
                    onPressed: _toggleSearch,
                  ),
                ]),
      body: _searchMode
          ? _buildSearchResults()
          : Column(children: [
              Expanded(
                  child: _MsgList(
                      msgs: _msgs,
                      myUid: _myUid,
                      onPlayVideo: widget.onPlayVideo,
                      onCard: _openCard,
                      onGrabPacket: _grabPacket,
                      scrollController: _scrollCtrl,
                      msgKeys: _msgKeys,
                      highlightMid: _highlightMid,
                      selectionMode: _selectMode,
                      selectedMids: _selectedMids,
                      onToggleSelect: _toggleSelect,
                      onEnterSelect: _enterSelectMode,
                      onProfile: (uid) => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                              builder: (_) => ProfilePage(
                                  uid: uid, onPlayVideo: widget.onPlayVideo))),
                      onReact: (mid, emoji) async {
                        await PlatformService.msgReact(
                            scope: 'dm', target: widget.peer, mid: mid, emoji: emoji);
                        _load();
                      },
                      onPat: (m) async {
                        await PlatformService.patUser(
                            scope: 'dm', target: widget.peer);
                        _load();
                      },
                      onRecall: _recallMsg,
                      onEdit: _editMsg,
                      onOpenLive: _openLiveAlert)),
              if (_selectMode)
                _buildSelectBar()
              else
                _ChatInput(
                    controller: _ctrl,
                    onSend: _send,
                    onRecommend: _recommend,
                    onTransfer: _transfer,
                    onRedpacket: _redpacket,
                    onCard: _sendCard,
                    onSticker: _openStickerPicker,
                    blocked: PlatformService.blacklistedUids.contains(widget.peer)),
            ]),
    );
  }
}

void _snack(BuildContext context, String m) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
}

/// 输入金额对话框。返回正整数或 null。
Future<int?> _askAmount(BuildContext context, String title) async {
  final ctrl = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(
            labelText: '兑换币金额', prefixIcon: Icon(Icons.paid)),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('确定')),
      ],
    ),
  );
  if (ok != true) return null;
  return int.tryParse(ctrl.text.trim());
}

// ============ 群聊天 ============
class _GroupChatPage extends StatefulWidget {
  final String gid;
  final void Function(String id, String title) onPlayVideo;
  const _GroupChatPage({required this.gid, required this.onPlayVideo});
  @override
  State<_GroupChatPage> createState() => _GroupChatPageState();
}

class _GroupChatPageState extends State<_GroupChatPage> {
  final _ctrl = TextEditingController();
  Map<String, dynamic> _info = {};
  List<Map<String, dynamic>> _msgs = [];
  String? _myUid;
  Timer? _draftTimer;
  bool _annExpanded = false;
  String get _draftKey => 'grp:${widget.gid}';
  String get _announcement => '${_info['announcement'] ?? ''}';
  int get _announcementTs => (_info['announcement_ts'] as num?)?.toInt() ?? 0;

  // 本会话搜索：搜索框防抖调用带 q 的 groupMsgs，命中结果点击后跳转/定位到该消息附近。
  bool _searchMode = false;
  final _searchCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final Map<String, GlobalKey> _msgKeys = {};
  Timer? _searchDebounce;
  bool _searching = false;
  List<Map<String, dynamic>> _searchResults = [];
  String? _highlightMid;

  // 消息多选：长按菜单点"多选"进入，勾选后底部栏可批量转发/批量删除(=批量撤回自己的消息)。
  bool _selectMode = false;
  final Set<String> _selectedMids = {};

  @override
  void initState() {
    super.initState();
    PlatformService.activeChatKey = 'grp:${widget.gid}'; // 正在看，别给这群弹通知
    PlatformService.walletUid()
        .then((u) => mounted ? setState(() => _myUid = u) : null);
    _load();
    _ctrl.addListener(_onDraftChanged);
    _ChatDraft.load(_draftKey).then((t) {
      if (mounted && t.isNotEmpty) {
        _ctrl.text = t;
        _ctrl.selection =
            TextSelection.fromPosition(TextPosition(offset: _ctrl.text.length));
      }
    });
  }

  void _onDraftChanged() {
    _draftTimer?.cancel();
    _draftTimer = Timer(const Duration(milliseconds: 500),
        () => _ChatDraft.save(_draftKey, _ctrl.text));
  }

  @override
  void dispose() {
    if (PlatformService.activeChatKey == 'grp:${widget.gid}') {
      PlatformService.activeChatKey = null;
    }
    _draftTimer?.cancel();
    _ChatDraft.save(_draftKey, _ctrl.text); // 兜底落盘
    _ctrl.removeListener(_onDraftChanged);
    _searchDebounce?.cancel();
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _toggleSearch() {
    setState(() {
      _searchMode = !_searchMode;
      if (!_searchMode) {
        _searchDebounce?.cancel();
        _searchCtrl.clear();
        _searchResults = [];
        _searching = false;
      }
    });
  }

  void _onSearchChanged(String v) {
    _searchDebounce?.cancel();
    _searchDebounce =
        Timer(const Duration(milliseconds: 350), () => _runSearch(v));
  }

  Future<void> _runSearch(String q) async {
    final query = q.trim();
    if (query.isEmpty) {
      if (mounted) setState(() => _searchResults = []);
      return;
    }
    if (mounted) setState(() => _searching = true);
    final d = await PlatformService.groupMsgs(widget.gid, q: query);
    if (!mounted) return;
    setState(() {
      _searching = false;
      _searchResults = ((d?['msgs'] as List?) ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    });
  }

  // 跳转/定位到该消息附近：先按索引比例粗定位，再等这一帧建好后用 ensureVisible 精定位，
  // 并临时高亮几秒方便肉眼找到（消息数量有限，全量已加载，不做分页翻页）。
  Future<void> _jumpToMsg(String mid) async {
    if (mid.isEmpty) return;
    setState(() {
      _searchMode = false;
      _highlightMid = mid;
    });
    final idx = _msgs.indexWhere((m) => m['mid'] == mid);
    if (idx < 0) return;
    await Future.delayed(const Duration(milliseconds: 60));
    if (!mounted) return;
    if (_scrollCtrl.hasClients && _msgs.length > 1) {
      final frac = idx / (_msgs.length - 1);
      final target = (_scrollCtrl.position.maxScrollExtent * frac)
          .clamp(0.0, _scrollCtrl.position.maxScrollExtent);
      _scrollCtrl.jumpTo(target);
    }
    await Future.delayed(const Duration(milliseconds: 120));
    final ctx = _msgKeys[mid]?.currentContext;
    if (ctx != null && mounted) {
      await Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 250), alignment: 0.5);
    }
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted && _highlightMid == mid) setState(() => _highlightMid = null);
    });
  }

  Widget _buildSearchResults() {
    if (_searching) return const Center(child: CircularProgressIndicator());
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) {
      return const Center(
          child: Text('输入关键词搜索本群消息', style: TextStyle(color: Colors.black38)));
    }
    if (_searchResults.isEmpty) {
      return const Center(
          child: Text('没有找到相关消息', style: TextStyle(color: Colors.black38)));
    }
    return ListView.separated(
      itemCount: _searchResults.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) {
        final m = _searchResults[i];
        final fromNick = '${m['from_nick'] ?? ''}';
        final mine = m['from'] == _myUid;
        return ListTile(
          leading: Icon(mine ? Icons.arrow_upward : Icons.arrow_downward,
              size: 18, color: Colors.black45),
          title: _highlightMatch('${m['text'] ?? ''}', q),
          subtitle: Text(
              '${mine ? '我' : fromNick}  ${_fmtAgo((m['ts'] as num?)?.toInt() ?? 0)}',
              style: const TextStyle(fontSize: 11, color: Colors.black38)),
          onTap: () => _jumpToMsg('${m['mid'] ?? ''}'),
        );
      },
    );
  }

  Future<void> _load() async {
    final d = await PlatformService.groupMsgs(widget.gid);
    if (d != null && d['ok'] == true && mounted) {
      setState(() {
        _info = d;
        _msgs = ((d['msgs'] as List?) ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
      });
      // 进群聊即视为已读公告，清掉群列表的"新公告"标签
      if (_announcement.isNotEmpty) {
        _AnnouncementPrefs.markSeen(widget.gid, _announcementTs);
      }
    } else if (d != null && d['ok'] != true && mounted) {
      // 被踢/解散
      Navigator.of(context).pop();
    }
  }

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    _ctrl.clear();
    _draftTimer?.cancel();
    await _ChatDraft.clear(_draftKey);
    if (await PlatformService.groupSend(widget.gid, text: t)) _load();
  }

  Future<void> _recommend() async {
    final v = await _pickVideo(context);
    if (v == null) return;
    if (await PlatformService.groupSend(widget.gid,
        vid: v['id'] as String, title: v['title'] as String)) _load();
  }

  Future<void> _sendCard() async {
    final picked = await _pickUser(context);
    if (picked == null) return;
    final ok =
        await PlatformService.groupSend(widget.gid, card: picked['uid'] as String);
    if (ok) _load();
  }

  void _openCard(String uid, String nick) {
    if (uid.isEmpty) return;
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => _ChatPage(
          peer: uid, peerNick: nick, onPlayVideo: widget.onPlayVideo),
    ));
  }

  // 群里发拼手气红包（成员抢）。
  Future<void> _redpacket() async {
    final totalCtrl = TextEditingController(text: '20');
    final partsCtrl = TextEditingController(text: '5');
    final msgCtrl = TextEditingController(text: '恭喜发财');
    // 群成员（排除自己）用于「专属红包」指定收礼人
    final nickMap = Map<String, dynamic>.from(
        (_info['member_nicks'] as Map?) ?? const {});
    final members = ((_info['members'] as List?) ?? [])
        .map((e) => '$e')
        .where((u) => u.isNotEmpty && u != _myUid)
        .toList();
    String? toUid; // null=拼手气群红包；非空=专属给某人
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          final exclusive = toUid != null;
          return AlertDialog(
            backgroundColor: const Color(0xFFC0392B),
            title: Text(exclusive ? '🧧 专属红包' : '🧧 群红包（拼手气）',
                style: const TextStyle(color: Color(0xFFFFE2A8))),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                  controller: totalCtrl,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                      labelText: '总额',
                      labelStyle: TextStyle(color: Colors.white70))),
              if (!exclusive)
                TextField(
                    controller: partsCtrl,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                        labelText: '个数（多于群人数则可继续抢）',
                        labelStyle: TextStyle(color: Colors.white70))),
              TextField(
                  controller: msgCtrl,
                  maxLength: 40,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                      labelText: '祝福语',
                      labelStyle: TextStyle(color: Colors.white70),
                      counterStyle: TextStyle(color: Colors.white54))),
              const SizedBox(height: 6),
              if (members.isNotEmpty)
                Align(
                    alignment: Alignment.centerLeft,
                    child: DropdownButton<String?>(
                        value: toUid,
                        isExpanded: true,
                        dropdownColor: const Color(0xFF8E2A20),
                        iconEnabledColor: Colors.white70,
                        style: const TextStyle(color: Colors.white),
                        hint: const Text('发给所有人（拼手气）',
                            style: TextStyle(color: Colors.white70)),
                        items: [
                          const DropdownMenuItem<String?>(
                              value: null,
                              child: Text('发给所有人（拼手气）',
                                  style: TextStyle(color: Colors.white))),
                          for (final u in members)
                            DropdownMenuItem<String?>(
                                value: u,
                                child: Text('专属给 ${nickMap[u] ?? u}',
                                    style:
                                        const TextStyle(color: Colors.white))),
                        ],
                        onChanged: (v) => setDlg(() => toUid = v))),
            ]),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('取消',
                      style: TextStyle(color: Colors.white70))),
              FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD24A),
                      foregroundColor: const Color(0xFF7A1F18)),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text(exclusive ? '发专属红包' : '塞钱发群里')),
            ],
          );
        },
      ),
    );
    if (ok != true) return;
    final total = int.tryParse(totalCtrl.text.trim()) ?? 0;
    final parts =
        toUid != null ? 1 : (int.tryParse(partsCtrl.text.trim()) ?? 0);
    final d = await PlatformService.chatPacket(
        scope: 'group',
        target: widget.gid,
        ptype: 'redpacket',
        amount: total,
        parts: parts,
        msg: msgCtrl.text.trim(),
        to: toUid ?? '');
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _snack(context, toUid != null ? '🧧 专属红包已发' : '🧧 群红包已发，等大家抢');
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '发红包失败'}');
    }
  }

  Future<Map<String, dynamic>?> _grabPacket(String pid) async {
    final d = await PlatformService.packetGrab(pid);
    if (mounted) _load();
    return d;
  }

  // 本地乐观更新：用服务端返回的最新 msg 原地替换列表里对应 mid 的那条，不等下次轮询。
  void _applyMsgPatch(String mid, Map<String, dynamic>? newMsg) {
    if (newMsg == null || !mounted) return;
    setState(() {
      final i = _msgs.indexWhere((x) => x['mid'] == mid);
      if (i != -1) _msgs[i] = Map<String, dynamic>.from(newMsg);
    });
  }

  Future<void> _recallMsg(Map<String, dynamic> m) async {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty) return;
    final d = await PlatformService.msgRecall(
        scope: 'group', target: widget.gid, mid: mid);
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _applyMsgPatch(mid, d['msg'] as Map<String, dynamic>?);
    } else {
      _snack(context, '${d?['error'] ?? '撤回失败'}');
    }
  }

  Future<void> _editMsg(Map<String, dynamic> m, String text) async {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty) return;
    final d = await PlatformService.msgEdit(
        scope: 'group', target: widget.gid, mid: mid, text: text);
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _applyMsgPatch(mid, d['msg'] as Map<String, dynamic>?);
    } else {
      _snack(context, '${d?['error'] ?? '编辑失败'}');
    }
  }

  // 表情包面板：选中"我的收藏"直接发；精品表情要消耗积分，发前二次确认。
  Future<void> _openStickerPicker() async {
    final picked = await _pickSticker(context);
    if (picked == null || !mounted) return;
    final cost = (picked['cost'] as num?)?.toInt() ?? 0;
    if (cost > 0) {
      final ok = await _confirm(context, '发送精品表情', '将消耗 $cost 兑换币，确定发送吗？');
      if (!ok || !mounted) return;
    }
    final d = await PlatformService.sendSticker(
        scope: 'group', target: widget.gid, stickerId: '${picked['id']}');
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '发送失败'}');
    }
  }

  // 点"XX 正在直播"提醒卡片：进直播间(若已下播，LiveRoomPage 会自己提示"直播已结束")。
  void _openLiveAlert(Map<String, dynamic> m) {
    final lid = '${m['lid'] ?? ''}';
    if (lid.isEmpty) return;
    Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => LiveRoomPage(
            lid: lid,
            isHost: false,
            title: '${m['live_nick'] ?? ''}的直播',
            onPlayVideo: widget.onPlayVideo)));
  }

  void _enterSelectMode(Map<String, dynamic> m) {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty) return;
    setState(() {
      _selectMode = true;
      _selectedMids
        ..clear()
        ..add(mid);
    });
  }

  void _toggleSelect(String mid) {
    setState(() {
      if (!_selectedMids.remove(mid)) _selectedMids.add(mid);
    });
  }

  void _exitSelectMode() {
    setState(() {
      _selectMode = false;
      _selectedMids.clear();
    });
  }

  Future<void> _batchForwardSelected() async {
    final msgs =
        _msgs.where((m) => _selectedMids.contains('${m['mid'] ?? ''}')).toList();
    await _forwardMessages(context, msgs);
    if (mounted) _exitSelectMode();
  }

  // 批量删除=批量撤回自己的消息，超时/非本人的会被服务端跳过，跳过原因合并成一句提示。
  Future<void> _batchDelete() async {
    if (_selectedMids.isEmpty) return;
    final d = await PlatformService.msgRecallBatch(
        scope: 'group', target: widget.gid, mids: _selectedMids.toList());
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      final revoked = ((d['revoked'] as List?) ?? const []).length;
      final skipped = (d['skipped'] as List?) ?? const [];
      final timeoutN =
          skipped.where((s) => s is Map && s['reason'] == '超时').length;
      final otherN = skipped.length - timeoutN;
      var msg = '已撤回 $revoked 条';
      if (timeoutN > 0) msg += '，$timeoutN条已超时未撤回';
      if (otherN > 0) msg += '，$otherN条无法撤回';
      _snack(context, msg);
      _load();
      _exitSelectMode();
    } else {
      _snack(context, '${d?['error'] ?? '批量撤回失败'}');
    }
  }

  // 多选模式下的底部操作栏：转发(N) / 删除(N)。
  Widget _buildSelectBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFE0E0E0))),
        ),
        child: Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _selectedMids.isEmpty ? null : _batchForwardSelected,
              icon: const Icon(Icons.forward, size: 18),
              label: Text('转发(${_selectedMids.length})'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent),
              onPressed: _selectedMids.isEmpty ? null : _batchDelete,
              icon: const Icon(Icons.delete_outline, size: 18),
              label: Text('删除(${_selectedMids.length})'),
            ),
          ),
        ]),
      ),
    );
  }

  String get _myRole {
    if (_info['owner'] == _myUid) return 'owner';
    if (((_info['admins'] as List?) ?? []).contains(_myUid)) return 'admin';
    return 'member';
  }

  // 群公告横幅：AppBar 下方，可点击展开/收起，仅公告非空时显示。
  Widget _buildAnnouncementBanner() {
    return Material(
      color: const Color(0xFFFFF3D6),
      child: InkWell(
        onTap: () => setState(() => _annExpanded = !_annExpanded),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Padding(
              padding: EdgeInsets.only(top: 2),
              child: Icon(Icons.campaign, size: 16, color: Color(0xFFB8860B)),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(_announcement,
                  maxLines: _annExpanded ? null : 1,
                  overflow: _annExpanded
                      ? TextOverflow.visible
                      : TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, color: Color(0xFF7A5B1E))),
            ),
            const SizedBox(width: 4),
            Icon(_annExpanded ? Icons.expand_less : Icons.expand_more,
                size: 18, color: const Color(0xFF7A5B1E)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDEDED),
      appBar: AppBar(
        leading: _selectMode
            ? IconButton(
                icon: const Icon(Icons.close), onPressed: _exitSelectMode)
            : null,
        title: _selectMode
            ? Text('已选择 ${_selectedMids.length} 条')
            : _searchMode
            ? TextField(
                controller: _searchCtrl,
                autofocus: true,
                style: const TextStyle(color: Colors.black87),
                decoration: const InputDecoration(
                    hintText: '搜索聊天记录',
                    hintStyle: TextStyle(color: Colors.black38),
                    border: InputBorder.none),
                onChanged: _onSearchChanged)
            : Text('${_info['name'] ?? '群聊'}'),
        backgroundColor: const Color(0xFFEDEDED),
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: _selectMode
            ? []
            : [
                IconButton(
                  icon: Icon(_searchMode ? Icons.close : Icons.search),
                  tooltip: _searchMode ? '取消搜索' : '搜索聊天记录',
                  onPressed: _toggleSearch,
                ),
                if (!_searchMode)
                  IconButton(
                    icon: const Icon(Icons.manage_accounts),
                    tooltip: '群管理',
                    onPressed: () => _openManage(),
                  ),
              ],
      ),
      body: _searchMode
          ? _buildSearchResults()
          : Column(children: [
              if (_announcement.isNotEmpty) _buildAnnouncementBanner(),
              Expanded(
                  child: _MsgList(
                      msgs: _msgs,
                      myUid: _myUid,
                      group: true,
                      onPlayVideo: widget.onPlayVideo,
                      onCard: _openCard,
                      onGrabPacket: _grabPacket,
                      scrollController: _scrollCtrl,
                      msgKeys: _msgKeys,
                      highlightMid: _highlightMid,
                      selectionMode: _selectMode,
                      selectedMids: _selectedMids,
                      onToggleSelect: _toggleSelect,
                      onEnterSelect: _enterSelectMode,
                      onReact: (mid, emoji) async {
                        await PlatformService.msgReact(
                            scope: 'group',
                            target: widget.gid,
                            mid: mid,
                            emoji: emoji);
                        _load();
                      },
                      onPat: (m) async {
                        await PlatformService.patUser(
                            scope: 'group',
                            target: widget.gid,
                            to: '${m['from'] ?? ''}');
                        _load();
                      },
                      onRecall: _recallMsg,
                      onEdit: _editMsg,
                      onOpenLive: _openLiveAlert,
                      gid: widget.gid,
                      onRefresh: _load,
                      onProfile: _openProfile)),
              if (_selectMode)
                _buildSelectBar()
              else
                _ChatInput(
                    controller: _ctrl,
                    onSend: _send,
                    onRecommend: _recommend,
                    onRedpacket: _redpacket,
                    onCard: _sendCard,
                    onSticker: _openStickerPicker,
                    myUid: _myUid,
                    onMore: _showGroupTools,
                    atMembers: Map<String, String>.from(
                        (_info['member_nicks'] as Map?) ?? const {})),
            ]),
    );
  }

  void _openProfile(String uid) {
    Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => ProfilePage(
            uid: uid, onPlayVideo: widget.onPlayVideo)));
  }

  // 「+」工具：发起投票 / 接龙 / 一起看。
  void _showGroupTools() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.bar_chart, color: Color(0xFF07C160)),
              title: const Text('发起投票'),
              onTap: () {
                Navigator.pop(ctx);
                _createPoll();
              }),
          ListTile(
              leading: const Icon(Icons.format_list_numbered,
                  color: Color(0xFFE3A93B)),
              title: const Text('发起接龙'),
              onTap: () {
                Navigator.pop(ctx);
                _createJielong();
              }),
          ListTile(
              leading: const Icon(Icons.groups, color: Color(0xFF5B6EE8)),
              title: const Text('一起看视频'),
              onTap: () {
                Navigator.pop(ctx);
                _startWatch();
              }),
        ]),
      ),
    );
  }

  Future<void> _createPoll() async {
    final qCtrl = TextEditingController();
    final optCtrls = [TextEditingController(), TextEditingController()];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('发起投票'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                  controller: qCtrl,
                  maxLength: 120,
                  decoration: const InputDecoration(labelText: '投票问题')),
              for (var i = 0; i < optCtrls.length; i++)
                TextField(
                    controller: optCtrls[i],
                    maxLength: 60,
                    decoration:
                        InputDecoration(labelText: '选项 ${i + 1}')),
              if (optCtrls.length < 8)
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text('加选项'),
                    onPressed: () =>
                        setD(() => optCtrls.add(TextEditingController())),
                  ),
                ),
            ]),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('发起')),
          ],
        ),
      ),
    );
    final q = qCtrl.text.trim();
    final opts =
        optCtrls.map((c) => c.text.trim()).where((s) => s.isNotEmpty).toList();
    qCtrl.dispose();
    for (final c in optCtrls) {
      c.dispose();
    }
    if (ok != true || q.isEmpty || opts.length < 2) return;
    final d = await PlatformService.pollCreate(widget.gid, q, opts);
    if (!mounted) return;
    if (d?['ok'] == true) {
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '发起失败'}');
    }
  }

  Future<void> _createJielong() async {
    final titleCtrl = TextEditingController();
    final firstCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('发起接龙'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: titleCtrl,
              maxLength: 80,
              decoration: const InputDecoration(labelText: '接龙主题')),
          TextField(
              controller: firstCtrl,
              maxLength: 80,
              decoration: const InputDecoration(labelText: '我先来一条（选填）')),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('发起')),
        ],
      ),
    );
    final title = titleCtrl.text.trim();
    final first = firstCtrl.text.trim();
    titleCtrl.dispose();
    firstCtrl.dispose();
    if (ok != true || title.isEmpty) return;
    final d = await PlatformService.jielongCreate(widget.gid, title, first);
    if (!mounted) return;
    if (d?['ok'] == true) {
      _load();
    } else {
      _snack(context, '${d?['error'] ?? '发起失败'}');
    }
  }

  Future<void> _startWatch() async {
    final v = await _pickVideo(context);
    if (v == null || !mounted) return;
    final d = await PlatformService.watchStart(
        widget.gid, v['id'] as String, v['title'] as String);
    if (!mounted) return;
    if (d?['ok'] == true) {
      _load();
      // 发起人自己也开始看
      widget.onPlayVideo(v['id'] as String, v['title'] as String);
    } else {
      _snack(context, '${d?['error'] ?? '发起失败'}');
    }
  }

  void _openManage() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _GroupManageSheet(
        gid: widget.gid,
        info: _info,
        myUid: _myUid,
        myRole: _myRole,
        onChanged: () {
          Navigator.pop(context);
          _load();
        },
        onLeftOrDisbanded: () {
          Navigator.pop(context); // sheet
          Navigator.pop(context); // chat
        },
      ),
    );
  }
}

// ============ 群管理面板 ============
class _GroupManageSheet extends StatefulWidget {
  final String gid;
  final Map<String, dynamic> info;
  final String? myUid;
  final String myRole;
  final VoidCallback onChanged;
  final VoidCallback onLeftOrDisbanded;
  const _GroupManageSheet(
      {required this.gid,
      required this.info,
      required this.myUid,
      required this.myRole,
      required this.onChanged,
      required this.onLeftOrDisbanded});
  @override
  State<_GroupManageSheet> createState() => _GroupManageSheetState();
}

class _GroupManageSheetState extends State<_GroupManageSheet> {
  bool _busy = false;

  Future<void> _op(String op, {String target = '', bool on = true}) async {
    if (_busy) return;
    setState(() => _busy = true);
    final d = await PlatformService.groupOp(widget.gid, op,
        target: target, on: on);
    if (!mounted) return;
    setState(() => _busy = false);
    if (d == null) {
      _toast('操作失败，请检查网络');
      return;
    }
    if (d['ok'] == true) {
      if (op == 'disband' || op == 'leave') {
        widget.onLeftOrDisbanded();
      } else {
        widget.onChanged();
      }
    } else {
      _toast('${d['error'] ?? '操作失败'}');
    }
  }

  void _toast(String m) {
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(m)));
    }
  }

  Future<void> _rename() async {
    final ctrl =
        TextEditingController(text: '${widget.info['name'] ?? ''}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('修改群名'),
        content: TextField(
            controller: ctrl, autofocus: true, maxLength: 30),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('保存')),
        ],
      ),
    );
    if (ok != true) return;
    final name = ctrl.text.trim();
    if (name.isEmpty) return;
    setState(() => _busy = true);
    final d = await PlatformService.groupOp(widget.gid, 'rename', name: name);
    if (!mounted) return;
    setState(() => _busy = false);
    if (d != null && d['ok'] == true) {
      widget.onChanged();
    } else {
      _toast('${d?['error'] ?? '改名失败'}');
    }
  }

  Future<void> _editAnnouncement() async {
    final ctrl =
        TextEditingController(text: '${widget.info['announcement'] ?? ''}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('群公告'),
        content: TextField(
            controller: ctrl,
            autofocus: true,
            maxLines: 5,
            maxLength: 500,
            decoration: const InputDecoration(hintText: '输入公告内容，留空可清空公告')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('保存')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _busy = true);
    final d = await PlatformService.groupOp(widget.gid, 'announcement',
        text: ctrl.text.trim());
    if (!mounted) return;
    setState(() => _busy = false);
    if (d != null && d['ok'] == true) {
      widget.onChanged();
    } else {
      _toast('${d?['error'] ?? '公告更新失败'}');
    }
  }

  Future<void> _transferOwner() async {
    final owner = '${widget.info['owner']}';
    final candidates = ((widget.info['members'] as List?) ?? [])
        .map((e) => '$e')
        .where((m) => m != owner)
        .toList();
    if (candidates.isEmpty) {
      _toast('群里还没有其他成员');
      return;
    }
    final nicks =
        Map<String, dynamic>.from((widget.info['member_nicks'] as Map?) ?? const {});
    String showName(String m) =>
        '${nicks[m] ?? (m.length > 6 ? m.substring(m.length - 6) : m)}';
    final target = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.5,
        maxChildSize: 0.9,
        builder: (_, sc) => ListView(
          controller: sc,
          children: [
            const Padding(
              padding: EdgeInsets.all(14),
              child: Text('选择新群主',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ),
            for (final m in candidates)
              ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(showName(m)),
                onTap: () => Navigator.pop(context, m),
              ),
          ],
        ),
      ),
    );
    if (target == null || !mounted) return;
    final ok = await _confirm(context, '转让群主',
        '转让后 ${showName(target)} 将成为新群主，你将变为管理员，确定吗？');
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final d = await PlatformService.groupOp(widget.gid, 'transfer_owner',
        target: target);
    if (!mounted) return;
    setState(() => _busy = false);
    if (d != null && d['ok'] == true) {
      widget.onChanged();
    } else {
      _toast('${d?['error'] ?? '转让失败'}');
    }
  }

  Future<void> _invite() async {
    if (_busy) return;
    final picked = await _pickUser(context);
    if (picked == null || !mounted) return;
    setState(() => _busy = true);
    final ok =
        await PlatformService.groupInvite(widget.gid, picked['uid'] as String);
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      widget.onChanged();
    } else {
      _toast('邀请失败（群可能已满或对方被封禁）');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final owner = '${widget.info['owner']}';
    final admins = ((widget.info['admins'] as List?) ?? []).cast<dynamic>();
    final members =
        ((widget.info['members'] as List?) ?? []).cast<dynamic>();
    final isOwner = widget.myRole == 'owner';
    final isAdmin = widget.myRole == 'owner' || widget.myRole == 'admin';
    final noLeave = widget.info['no_leave'] == true;
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      maxChildSize: 0.95,
      builder: (_, sc) => ListView(
        controller: sc,
        children: [
          const Padding(
            padding: EdgeInsets.all(14),
            child: Text('群管理',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
          if (isAdmin)
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('修改群名'),
              subtitle: Text('${widget.info['name'] ?? ''}'),
              onTap: _busy ? null : _rename,
            ),
          if (isAdmin)
            ListTile(
              leading: const Icon(Icons.campaign_outlined),
              title: const Text('编辑公告'),
              subtitle: Text(
                  '${widget.info['announcement'] ?? ''}'.isEmpty ? '暂无公告' : '${widget.info['announcement']}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              onTap: _busy ? null : _editAnnouncement,
            ),
          if (isOwner)
            SwitchListTile(
              title: const Text('禁止成员退群'),
              subtitle: const Text('开启后普通成员无法主动退群'),
              value: noLeave,
              onChanged: _busy ? null : (v) => _op('noleave', on: v),
            ),
          if (isOwner)
            ListTile(
              leading: const Icon(Icons.swap_horiz),
              title: const Text('转让群主'),
              subtitle: const Text('转让后你将变为管理员'),
              onTap: _busy ? null : _transferOwner,
            ),
          ListTile(
            leading: const Icon(Icons.person_add),
            title: const Text('邀请成员'),
            onTap: _invite,
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Text('成员（${members.length}）',
                style: const TextStyle(color: Colors.black54)),
          ),
          for (final m in members)
            _MemberRow(
              uid: '$m',
              isOwnerRow: '$m' == owner,
              isAdminRow: admins.contains(m),
              meIsOwner: isOwner,
              meIsAdmin: isAdmin,
              isSelf: '$m' == widget.myUid,
              busy: _busy,
              accent: cs.primary,
              onSetAdmin: (on) => _op('admin', target: '$m', on: on),
              onKick: () => _op('kick', target: '$m'),
            ),
          const Divider(),
          if (isOwner)
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: const Text('解散群',
                  style: TextStyle(color: Colors.red)),
              onTap: _busy
                  ? null
                  : () async {
                      final ok = await _confirm(context, '解散群', '解散后群聊和消息都会删除，不可恢复。');
                      if (ok) _op('disband');
                    },
            )
          else
            ListTile(
              leading: const Icon(Icons.exit_to_app),
              title: Text(noLeave ? '退群（群主已禁止）' : '退出群聊'),
              enabled: !noLeave && !_busy,
              onTap: () => _op('leave'),
            ),
        ],
      ),
    );
  }
}

class _MemberRow extends StatelessWidget {
  final String uid;
  final bool isOwnerRow, isAdminRow, meIsOwner, meIsAdmin, isSelf, busy;
  final Color accent;
  final void Function(bool on) onSetAdmin;
  final VoidCallback onKick;
  const _MemberRow(
      {required this.uid,
      required this.isOwnerRow,
      required this.isAdminRow,
      required this.meIsOwner,
      required this.meIsAdmin,
      required this.isSelf,
      required this.busy,
      required this.accent,
      required this.onSetAdmin,
      required this.onKick});

  @override
  Widget build(BuildContext context) {
    final tag = isOwnerRow
        ? '群主'
        : isAdminRow
            ? '管理'
            : '';
    // 群主可设/撤管理、踢任何非群主；管理可踢普通成员。
    final canKick = !isOwnerRow &&
        !isSelf &&
        (meIsOwner || (meIsAdmin && !isAdminRow));
    return ListTile(
      dense: true,
      leading: CircleAvatar(
          radius: 16,
          backgroundColor: isOwnerRow ? accent : Colors.black12,
          child: Icon(Icons.person,
              size: 18,
              color: isOwnerRow ? Colors.white : Colors.black45)),
      title: Text('…${uid.length > 6 ? uid.substring(uid.length - 6) : uid}'),
      subtitle: tag.isEmpty ? null : Text(tag),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (meIsOwner && !isOwnerRow)
          TextButton(
            onPressed: busy ? null : () => onSetAdmin(!isAdminRow),
            child: Text(isAdminRow ? '撤管理' : '设管理'),
          ),
        if (canKick)
          IconButton(
            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
            tooltip: '踢出',
            onPressed: busy ? null : onKick,
          ),
      ]),
    );
  }
}

// 转发目标选择器(联系人/群多选)：单条转发、批量转发共用同一套弹层。取消或未选返回 null。
Future<Set<String>?> _pickForwardTargets(BuildContext context) async {
  final users = await PlatformService.users();
  final groups = await PlatformService.groupList();
  if (!context.mounted) return null;
  final sel = <String>{}; // 'dm:uid' / 'grp:gid'
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        builder: (ctx, scroll) => Column(children: [
          Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                const Text('转发给',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const Spacer(),
                FilledButton(
                    onPressed:
                        sel.isEmpty ? null : () => Navigator.pop(ctx, true),
                    child: Text('发送(${sel.length})')),
              ])),
          Expanded(
            child: ListView(controller: scroll, children: [
              if (groups.isNotEmpty)
                const Padding(
                    padding: EdgeInsets.fromLTRB(16, 4, 0, 4),
                    child: Text('群聊',
                        style: TextStyle(fontSize: 12, color: Colors.black45))),
              for (final g in groups)
                CheckboxListTile(
                  dense: true,
                  value: sel.contains('grp:${g['gid']}'),
                  title: Text('👥 ${g['name']}'),
                  onChanged: (v) => setS(() => v == true
                      ? sel.add('grp:${g['gid']}')
                      : sel.remove('grp:${g['gid']}')),
                ),
              if (users.isNotEmpty)
                const Padding(
                    padding: EdgeInsets.fromLTRB(16, 8, 0, 4),
                    child: Text('联系人',
                        style: TextStyle(fontSize: 12, color: Colors.black45))),
              for (final u in users)
                CheckboxListTile(
                  dense: true,
                  value: sel.contains('dm:${u['uid']}'),
                  title: Text('👤 ${u['nick']}'),
                  onChanged: (v) => setS(() => v == true
                      ? sel.add('dm:${u['uid']}')
                      : sel.remove('dm:${u['uid']}')),
                ),
            ]),
          ),
        ]),
      );
    }),
  );
  if (ok != true || sel.isEmpty) return null;
  return sel;
}

// 把一条消息(文字/视频)发给选中的多个会话，返回成功份数。
Future<int> _sendToTargets(Set<String> targets, Map<String, dynamic> m) async {
  final isVid = m['kind'] == 'video';
  final text = '${m['text'] ?? ''}';
  var n = 0;
  for (final key in targets) {
    final i = key.indexOf(':');
    final type = key.substring(0, i);
    final id = key.substring(i + 1);
    bool sent;
    if (type == 'grp') {
      sent = await PlatformService.groupSend(id,
          text: isVid ? '' : text,
          vid: isVid ? '${m['vid']}' : '',
          title: isVid ? '${m['title'] ?? ''}' : '');
    } else {
      sent = await PlatformService.dmSend(id,
          text: isVid ? '' : text,
          vid: isVid ? '${m['vid']}' : '',
          title: isVid ? '${m['title'] ?? ''}' : '');
    }
    if (sent) n++;
  }
  return n;
}

// 批量转发(多选)：勾选的多条消息(仅文字/视频支持)一次性转发给选中的联系人/群。
Future<void> _forwardMessages(
    BuildContext context, List<Map<String, dynamic>> msgs) async {
  final forwardable = msgs
      .where(
          (m) => m['kind'] == 'video' || '${m['text'] ?? ''}'.trim().isNotEmpty)
      .toList();
  if (forwardable.isEmpty) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('选中的消息暂不支持转发')));
    return;
  }
  final sel = await _pickForwardTargets(context);
  if (sel == null) return;
  var n = 0;
  for (final m in forwardable) {
    n += await _sendToTargets(sel, m);
  }
  if (context.mounted) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('已转发 $n 条消息')));
  }
}

/// 表情包等媒体的相对路径(如 /sticker/xxx.png) 拼上当前生效的服务器地址；
/// 已是绝对 http(s) 链接则原样返回(预留：以后精品表情换成外链素材也兼容)。
String _fullMediaUrl(String path) =>
    path.startsWith('http') ? path : '${PlatformService.current}$path';

// ============ 共用：消息列表 / 输入栏 / 选人 / 选视频 ============
class _MsgList extends StatelessWidget {
  final List<Map<String, dynamic>> msgs;
  final String? myUid;
  final bool group;
  final void Function(String id, String title) onPlayVideo;
  final void Function(String uid, String nick)? onCard;
  final Future<Map<String, dynamic>?> Function(String pid)? onGrabPacket;
  final void Function(String mid, String emoji)? onReact; // 表情回应
  final void Function(Map<String, dynamic> msg)? onPat; // 拍一拍(双击对方消息)
  final void Function(Map<String, dynamic> msg)? onRecall; // 撤回(2分钟内自己的消息)
  final void Function(Map<String, dynamic> msg, String text)? onEdit; // 编辑(2分钟内自己的文本消息)
  final void Function(Map<String, dynamic> msg)? onOpenLive; // 点"XX正在直播"提醒卡片，进直播间
  final String? gid; // 群聊：投票/接龙/一起看用
  final VoidCallback? onRefresh; // 投票/接龙后刷新
  final void Function(String uid)? onProfile; // 点头像/名片看主页
  final ScrollController? scrollController; // 搜索结果"跳转到该消息"用
  final Map<String, GlobalKey>? msgKeys; // mid -> 消息行的 GlobalKey，跳转定位用
  final String? highlightMid; // 搜索跳转后临时高亮这一行，几秒后自动消失
  final bool selectionMode; // 多选模式：气泡前出现勾选框，点击整行即可勾选
  final Set<String> selectedMids; // 已勾选的 mid 集合
  final void Function(String mid)? onToggleSelect; // 勾选/取消勾选一条消息
  final void Function(Map<String, dynamic> msg)? onEnterSelect; // 长按菜单里点"多选"进入多选模式
  const _MsgList(
      {required this.msgs,
      required this.myUid,
      required this.onPlayVideo,
      this.onCard,
      this.onGrabPacket,
      this.onReact,
      this.onPat,
      this.onRecall,
      this.onEdit,
      this.onOpenLive,
      this.gid,
      this.onRefresh,
      this.onProfile,
      this.scrollController,
      this.msgKeys,
      this.highlightMid,
      this.selectionMode = false,
      this.selectedMids = const {},
      this.onToggleSelect,
      this.onEnterSelect,
      this.group = false});

  // 群投票气泡：问题 + 选项条(票数/百分比)，点选项投票。
  Widget _pollBubble(BuildContext context, Map<String, dynamic> m) {
    final poll = (m['poll'] as Map?) ?? const {};
    final q = '${poll['q'] ?? '投票'}';
    final options = (poll['options'] as List?)?.cast<dynamic>() ?? const [];
    final counts = (poll['counts'] as List?)?.cast<dynamic>() ?? const [];
    final total = (poll['total'] as num?)?.toInt() ?? 0;
    final myVote = (poll['my_vote'] as num?)?.toInt() ?? -1;
    return Container(
      width: 260,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.bar_chart, size: 18, color: Color(0xFF07C160)),
          const SizedBox(width: 4),
          Expanded(
              child: Text(q,
                  style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
        const SizedBox(height: 8),
        for (var i = 0; i < options.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: InkWell(
              onTap: () async {
                final pid = '${m['poll_id'] ?? ''}';
                if (pid.isEmpty) return;
                await PlatformService.pollVote(pid, i);
                onRefresh?.call();
              },
              child: Stack(children: [
                Container(
                  height: 30,
                  decoration: BoxDecoration(
                      color: const Color(0xFFF0F0F0),
                      borderRadius: BorderRadius.circular(5)),
                ),
                FractionallySizedBox(
                  widthFactor: total > 0
                      ? ((i < counts.length ? (counts[i] as num) : 0) / total)
                          .clamp(0.0, 1.0)
                      : 0.0,
                  child: Container(
                    height: 30,
                    decoration: BoxDecoration(
                        color: i == myVote
                            ? const Color(0xFF95EC69)
                            : const Color(0xFFD7EFD0),
                        borderRadius: BorderRadius.circular(5)),
                  ),
                ),
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(children: [
                      if (i == myVote)
                        const Icon(Icons.check_circle,
                            size: 15, color: Color(0xFF07C160)),
                      if (i == myVote) const SizedBox(width: 3),
                      Expanded(
                          child: Text('${options[i]}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 13))),
                      Text('${i < counts.length ? counts[i] : 0}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black54)),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        Text('共 $total 人投票',
            style: const TextStyle(fontSize: 11, color: Colors.black38)),
      ]),
    );
  }

  // 群接龙气泡：标题 + 编号列表 + 「我也接龙」。
  Widget _jielongBubble(BuildContext context, Map<String, dynamic> m) {
    final jl = (m['jielong'] as Map?) ?? const {};
    final title = '${jl['title'] ?? '接龙'}';
    final entries = (jl['entries'] as List?)?.cast<dynamic>() ?? const [];
    final count = (jl['count'] as num?)?.toInt() ?? entries.length;
    return Container(
      width: 260,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.format_list_numbered,
              size: 18, color: Color(0xFFE3A93B)),
          const SizedBox(width: 4),
          Expanded(
              child: Text('接龙：$title',
                  style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
        const Divider(height: 14),
        for (var i = 0; i < entries.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Builder(builder: (_) {
              final e = (entries[i] as Map?) ?? const {};
              return Text('${i + 1}. ${e['nick'] ?? ''}：${e['text'] ?? ''}',
                  style: const TextStyle(fontSize: 13));
            }),
          ),
        if (count > entries.length)
          Text('…共 $count 条', style: const TextStyle(fontSize: 11, color: Colors.black38)),
        const SizedBox(height: 6),
        Align(
          alignment: Alignment.centerLeft,
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
                visualDensity: VisualDensity.compact,
                foregroundColor: const Color(0xFFE3A93B)),
            icon: const Icon(Icons.add, size: 16),
            label: const Text('我也接龙'),
            onPressed: () async {
              final jid = '${m['jl_id'] ?? ''}';
              if (jid.isEmpty) return;
              final ctrl = TextEditingController();
              final ok = await showDialog<bool>(
                context: context,
                builder: (c) => AlertDialog(
                  title: Text('接龙：$title'),
                  content: TextField(
                      controller: ctrl,
                      maxLength: 80,
                      autofocus: true,
                      decoration: const InputDecoration(hintText: '写点啥…')),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(c, false),
                        child: const Text('取消')),
                    FilledButton(
                        onPressed: () => Navigator.pop(c, true),
                        child: const Text('接龙')),
                  ],
                ),
              );
              if (ok == true && ctrl.text.trim().isNotEmpty) {
                await PlatformService.jielongJoin(jid, ctrl.text.trim());
                onRefresh?.call();
              }
              ctrl.dispose();
            },
          ),
        ),
      ]),
    );
  }

  // 群一起看气泡：发起人 + 影片，点「加入观看」一起看同一视频。
  Widget _watchBubble(BuildContext context, Map<String, dynamic> m) {
    final vid = '${m['vid'] ?? ''}';
    final title = '${m['title'] ?? '视频'}';
    final nick = '${m['from_nick'] ?? ''}';
    return InkWell(
      onTap: vid.isEmpty ? null : () => onPlayVideo(vid, title),
      child: Container(
        width: 240,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Color(0xFF5B6EE8), Color(0xFF8E54E9)]),
            borderRadius: BorderRadius.circular(8)),
        child: Row(children: [
          const Icon(Icons.groups, color: Colors.white, size: 34),
          const SizedBox(width: 10),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text('$nick 发起了一起看',
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 11)),
                const SizedBox(height: 2),
                Text(title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 14)),
                const SizedBox(height: 4),
                const Text('▶ 点击加入观看',
                    style: TextStyle(color: Color(0xFFFFE9A8), fontSize: 12)),
              ])),
        ]),
      ),
    );
  }

  // 长按消息：选「表情回应」「转发」，自己发的2分钟内文本消息还有「编辑」「撤回」。
  void _msgActions(BuildContext context, Map<String, dynamic> m) {
    final mine = myUid != null && myUid!.isNotEmpty && m['from'] == myUid;
    final ts = (m['ts'] as num?)?.toInt() ?? 0;
    final withinWindow =
        (DateTime.now().millisecondsSinceEpoch ~/ 1000) - ts <= 120;
    final canRecall = mine && m['kind'] != 'revoked' && withinWindow;
    final canEdit = mine && m['kind'] == 'text' && withinWindow;
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Text('😀', style: TextStyle(fontSize: 22)),
              title: const Text('表情回应'),
              onTap: () {
                Navigator.pop(ctx);
                _showReactPicker(context, m);
              }),
          ListTile(
              leading: const Icon(Icons.forward, color: Color(0xFF07C160)),
              title: const Text('转发'),
              onTap: () {
                Navigator.pop(ctx);
                _forwardMessage(context, m);
              }),
          if (canEdit)
            ListTile(
                leading: const Icon(Icons.edit, color: Color(0xFF576B95)),
                title: const Text('编辑'),
                onTap: () {
                  Navigator.pop(ctx);
                  _editMessage(context, m);
                }),
          if (canRecall)
            ListTile(
                leading: const Icon(Icons.undo, color: Colors.redAccent),
                title: const Text('撤回'),
                onTap: () {
                  Navigator.pop(ctx);
                  onRecall?.call(m);
                }),
          ListTile(
              leading: const Icon(Icons.checklist, color: Color(0xFF576B95)),
              title: const Text('多选'),
              onTap: () {
                Navigator.pop(ctx);
                onEnterSelect?.call(m);
              }),
        ]),
      ),
    );
  }

  // 编辑弹窗：预填原文，保存后交给 onEdit 走乐观更新。
  Future<void> _editMessage(BuildContext context, Map<String, dynamic> m) async {
    final origin = '${m['text'] ?? ''}';
    final ctrl = TextEditingController(text: origin);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('编辑消息'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLines: 4,
          maxLength: 1000,
          decoration: const InputDecoration(hintText: '编辑内容…'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('保存')),
        ],
      ),
    );
    final text = ctrl.text.trim();
    ctrl.dispose();
    if (ok == true && text.isNotEmpty && text != origin) {
      onEdit?.call(m, text);
    }
  }

  // 单条转发：把这条消息(文字/视频)转发给多个联系人/群。目标选择器与批量转发共用 _pickForwardTargets。
  Future<void> _forwardMessage(
      BuildContext context, Map<String, dynamic> m) async {
    final isVid = m['kind'] == 'video';
    final text = '${m['text'] ?? ''}';
    if (!isVid && text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('该消息暂不支持转发')));
      return;
    }
    final sel = await _pickForwardTargets(context);
    if (sel == null) return;
    final n = await _sendToTargets(sel, m);
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('已转发给 $n 个会话')));
    }
  }

  // 长按消息弹表情选择条 → 切换回应。
  void _showReactPicker(BuildContext context, Map<String, dynamic> m) {
    final mid = '${m['mid'] ?? ''}';
    if (mid.isEmpty || onReact == null) return;
    const emojis = ['👍', '❤️', '😂', '😮', '😢', '🎉'];
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(28)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (final e in emojis)
              InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () {
                  Navigator.pop(ctx);
                  onReact!(mid, e);
                },
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(e, style: const TextStyle(fontSize: 26)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // 气泡下方的回应 chip 行（emoji + 人数，自己点过则高亮）。
  Widget? _reactionChips(Map<String, dynamic> m) {
    final r = m['reactions'];
    if (r is! Map || r.isEmpty) return null;
    final mid = '${m['mid'] ?? ''}';
    final chips = <Widget>[];
    r.forEach((emoji, who) {
      final list = (who is List) ? who : const [];
      if (list.isEmpty) return;
      final mineIn = myUid != null && list.contains(myUid);
      chips.add(GestureDetector(
        onTap: () => onReact?.call(mid, '$emoji'),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
          decoration: BoxDecoration(
            color: mineIn ? const Color(0xFFD7F0D0) : Colors.white,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(
                color: mineIn ? const Color(0xFF07C160) : Colors.black12),
          ),
          child: Text('$emoji ${list.length}',
              style: const TextStyle(fontSize: 12, color: Colors.black87)),
        ),
      ));
    });
    if (chips.isEmpty) return null;
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Wrap(spacing: 4, runSpacing: 4, children: chips),
    );
  }

  // 微信式红包/转账领取界面：红色封面 + 開/收款按钮 → 揭示金额。
  Future<void> _openPacket(BuildContext context, Map<String, dynamic> m) async {
    final isRed = m['ptype'] == 'redpacket';
    final blessing = '${m['msg'] ?? ''}'.trim().isEmpty
        ? (isRed ? '恭喜发财，大吉大利' : '给你转账')
        : '${m['msg']}';
    final fromNick = '${m['from_nick'] ?? ''}'.trim();
    final pid = '${m['pid'] ?? ''}';
    final claimed = m['_claimed'] == true;
    final done = m['_done'] == true;
    final canMore = m['_canmore'] == true;
    final myAmount = (m['_myamount'] as num?)?.toInt() ?? 0;
    String phase; // cover | opening | revealed | gone
    int amount = myAmount;
    String? errMsg;
    if (claimed && !canMore) {
      phase = 'revealed';
    } else if (done) {
      phase = 'gone';
    } else {
      phase = 'cover';
    }
    const red = Color(0xFFC73A2F);
    const red2 = Color(0xFFB02619);
    const gold = Color(0xFFF6D58A);
    await showDialog<void>(
      context: context,
      barrierColor: Colors.black54,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
        Widget body;
        if (phase == 'opening') {
          body = const SizedBox(
              height: 84,
              child: Center(child: CircularProgressIndicator(color: gold)));
        } else if (phase == 'revealed') {
          body = Column(mainAxisSize: MainAxisSize.min, children: [
            Text('$amount',
                style: const TextStyle(
                    color: gold, fontSize: 46, fontWeight: FontWeight.bold)),
            const Text('兑换币', style: TextStyle(color: gold, fontSize: 14)),
            const SizedBox(height: 8),
            Text(isRed ? '已存入你的零钱' : '已收款',
                style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ]);
        } else if (phase == 'gone') {
          body = Padding(
            padding: const EdgeInsets.symmetric(vertical: 18),
            child: Text(
                errMsg ??
                    (claimed
                        ? '已领取 $myAmount 兑换币'
                        : (isRed ? '手慢了，红包已被领完' : '已被领取')),
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 15)),
          );
        } else {
          body = GestureDetector(
            onTap: () async {
              setS(() => phase = 'opening');
              final r = await onGrabPacket?.call(pid);
              if (!ctx.mounted) return; // 领取途中关了弹窗
              if (r != null && r['ok'] == true) {
                setS(() {
                  amount = (r['amount'] as num?)?.toInt() ?? 0;
                  phase = 'revealed';
                });
              } else {
                setS(() {
                  errMsg = '${r?['error'] ?? '领取失败'}';
                  phase = 'gone';
                });
              }
            },
            child: Container(
              width: 78,
              height: 78,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                  color: gold,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Color(0x55000000), blurRadius: 8)
                  ]),
              child: Text(isRed ? '開' : '收',
                  style: const TextStyle(
                      color: red2,
                      fontSize: 30,
                      fontWeight: FontWeight.bold)),
            ),
          );
        }
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 48, vertical: 70),
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [red, red2]),
              borderRadius: BorderRadius.circular(14),
            ),
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: const Icon(Icons.close,
                          color: Colors.white54, size: 22))),
              const CircleAvatar(
                  radius: 22,
                  backgroundColor: gold,
                  child: Icon(Icons.person, color: red2)),
              const SizedBox(height: 8),
              Text(
                  fromNick.isEmpty
                      ? (isRed ? '红包' : '转账')
                      : '$fromNick 的${isRed ? '红包' : '转账'}',
                  style: const TextStyle(color: gold, fontSize: 13)),
              const SizedBox(height: 14),
              Text(blessing,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 24),
              body,
              const SizedBox(height: 6),
            ]),
          ),
        );
      }),
    );
  }

  Widget _packetBubble(BuildContext context, Map<String, dynamic> m, bool mine) {
    final isRed = m['ptype'] == 'redpacket';
    final msg = '${m['msg'] ?? ''}';
    final claimed = m['_claimed'] == true;
    final done = m['_done'] == true;
    final canMore = m['_canmore'] == true; // 个数>人数时同一人可继续抢
    final myAmount = (m['_myamount'] as num?)?.toInt() ?? 0;
    final toNick = '${m['to_nick'] ?? ''}'; // 专属红包指定人
    final exclusive = '${m['to'] ?? ''}'.isNotEmpty;

    String status;
    if (claimed && !canMore) {
      status = isRed ? '已领 $myAmount 币' : '已收款 $myAmount 币';
    } else if (mine && !canMore) {
      status = done
          ? (isRed ? '已被领完' : '已被领取')
          : (isRed ? '红包待领取' : '等待对方收款');
    } else if (done) {
      status = isRed ? '手慢了，已抢光' : '已被领取';
    } else {
      status = claimed ? '已领 $myAmount 币 · 还能再抢' : (isRed ? '点击领取红包' : '点击收款');
    }

    final faded = (claimed && !canMore) || done;

    // Merged authoritative WeChat-style palette.
    final bodyColor = faded ? const Color(0xFFFBDCA8) : const Color(0xFFFA9D3B);
    final footerColor = faded ? const Color(0xFFF0CB8C) : const Color(0xFFE2872C);
    final titleColor = faded ? const Color(0xFF9A7B4B) : const Color(0xFFFFFCF5);
    final statusColor = faded ? const Color(0xFFB39A6E) : const Color(0xFFFBE7C8);
    final footerLabelColor =
        faded ? const Color(0xFFBBA579) : const Color(0xFFFFF3DC);
    final exclusiveColor =
        faded ? const Color(0xFFB39A6E) : const Color(0xFFFFD24A);
    final emblemBg = faded ? const Color(0xFFE6D2A6) : const Color(0xFFF8D88C);
    const emblemGlyph = Color(0xFFC8431E);

    final brand = isRed ? '趣播红包' : '趣播转账';

    return InkWell(
      onTap: () => _openPacket(context, m), // 点开微信式领取界面
      child: Container(
        width: 240,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(
              color: Color(0x1F000000),
              offset: Offset(0, 1),
              blurRadius: 3,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top amber body.
            Container(
              color: bodyColor,
              padding: const EdgeInsets.fromLTRB(12, 14, 12, 14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Opacity(
                    opacity: faded ? 0.55 : 1.0,
                    child: Container(
                      width: 38,
                      height: 38,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: emblemBg,
                        shape: BoxShape.circle,
                      ),
                      child: isRed
                          ? const Text(
                              '￥',
                              style: TextStyle(
                                color: emblemGlyph,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              ),
                            )
                          : const Icon(
                              Icons.swap_horiz,
                              color: emblemGlyph,
                              size: 22,
                            ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          msg.isEmpty ? (isRed ? '恭喜发财，大吉大利' : '给你转账') : msg,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: titleColor,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (exclusive) ...[
                          const SizedBox(height: 3),
                          Text(
                            '专属红包 · 仅 $toNick 可领',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: exclusiveColor,
                              fontSize: 10,
                            ),
                          ),
                        ],
                        const SizedBox(height: 4),
                        Text(
                          status,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: statusColor,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Bottom darker footer strip with brand label.
            Container(
              height: 30,
              color: footerColor,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              alignment: Alignment.centerLeft,
              child: Text(
                brand,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: footerLabelColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (msgs.isEmpty) {
      return const Center(
          child: Text('还没有消息，发一条吧~',
              style: TextStyle(color: Colors.black38)));
    }
    return ListView.builder(
      controller: scrollController,
      padding: const EdgeInsets.all(10),
      itemCount: msgs.length,
      itemBuilder: (_, i) {
        final m = msgs[i];
        final mid = '${m['mid'] ?? ''}';
        // 搜索结果"跳转到该消息"用：mid -> 这一行的 GlobalKey，供 Scrollable.ensureVisible 定位。
        final rowKey = (msgKeys != null && mid.isNotEmpty)
            ? (msgKeys![mid] ??= GlobalKey())
            : null;
        final isHighlight = highlightMid != null && mid == highlightMid;
        final rowBg = isHighlight ? const Color(0x55FFD54F) : null;
        // 拍一拍：居中灰色系统提示行。
        if (m['kind'] == 'pat') {
          final fn = '${m['from_nick'] ?? ''}';
          final tn = '${m['to_nick'] ?? ''}';
          final meFrom = m['from'] == myUid;
          final meTo = m['to'] == myUid;
          final who = meFrom ? '你' : fn;
          final whom = meTo ? '你' : tn;
          return Container(
            key: rowKey,
            color: rowBg,
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Center(
              child: Text('$who 拍了拍 $whom',
                  style: const TextStyle(fontSize: 12, color: Colors.black45)),
            ),
          );
        }
        // 撤回：居中灰色斜体提示行，不展示原内容。
        if (m['kind'] == 'revoked') {
          final mine = m['from'] == myUid;
          return Container(
            key: rowKey,
            color: rowBg,
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Center(
              child: Text(mine ? '你撤回了一条消息' : '对方撤回了一条消息',
                  style: const TextStyle(
                      fontSize: 12,
                      color: Colors.black45,
                      fontStyle: FontStyle.italic)),
            ),
          );
        }
        final mine = m['from'] == myUid;
        final isVideo = m['kind'] == 'video';
        final isCard = m['kind'] == 'card';
        final isPacket = m['kind'] == 'packet';
        final isSticker = m['kind'] == 'sticker';
        final isLiveAlert = m['kind'] == 'live_alert'; // 关注的主播开播提醒卡片
        final kind = m['kind'];
        final bubble = kind == 'poll'
            ? _pollBubble(context, m)
            : kind == 'jielong'
            ? _jielongBubble(context, m)
            : kind == 'watch'
            ? _watchBubble(context, m)
            : isPacket
            ? _packetBubble(context, m, mine)
            : isCard
            ? InkWell(
                onTap: () => onCard?.call(
                    '${m['card']}', '${m['card_nick'] ?? ''}'),
                child: Container(
                  width: 210,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6)),
                  child: Row(children: [
                    const CircleAvatar(
                        radius: 20,
                        backgroundColor: Color(0xFF07C160),
                        child: Icon(Icons.contact_page,
                            color: Colors.white, size: 22)),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text('${m['card_nick'] ?? ''}',
                              style: const TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w600)),
                          const Text('个人名片',
                              style: TextStyle(
                                  fontSize: 11, color: Colors.black45)),
                        ])),
                  ]),
                ),
              )
            : isLiveAlert
            // 开播提醒：直播小红点图标 + "XX 正在直播"，点击直达直播间。
            ? InkWell(
                onTap: () => onOpenLive?.call(m),
                child: Container(
                  width: 210,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6)),
                  child: Row(children: [
                    Stack(clipBehavior: Clip.none, children: [
                      const Icon(Icons.podcasts,
                          color: Color(0xFFE5424D), size: 28),
                      Positioned(
                        right: -1,
                        top: -1,
                        child: Container(
                          width: 9,
                          height: 9,
                          decoration: BoxDecoration(
                              color: const Color(0xFFFF3B30),
                              shape: BoxShape.circle,
                              border:
                                  Border.all(color: Colors.white, width: 1.5)),
                        ),
                      ),
                    ]),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          const Text('直播提醒',
                              style: TextStyle(
                                  fontSize: 10, color: Colors.black45)),
                          Text('${m['live_nick'] ?? ''} 正在直播',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w600)),
                        ])),
                  ]),
                ),
              )
            : isVideo
            ? InkWell(
                onTap: () => onPlayVideo(
                    '${m['vid']}', '${m['title'] ?? '推荐视频'}'),
                child: Container(
                  width: 210,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: mine ? const Color(0xFF95EC69) : Colors.white,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Row(children: [
                    const Icon(Icons.play_circle_fill,
                        color: Color(0xFF07C160), size: 30),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('推荐视频',
                                style: TextStyle(
                                    fontSize: 10, color: Colors.black45)),
                            Text('${m['title'] ?? ''}',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.black87)),
                          ]),
                    ),
                  ]),
                ),
              )
            : isSticker
            // 表情包：不带气泡背景的大图，加载失败(如网络切换/文件已被清理)时显示占位图标。
            ? Image.network(
                _fullMediaUrl('${m['url'] ?? ''}'),
                width: 130,
                height: 130,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Container(
                    width: 90,
                    height: 90,
                    alignment: Alignment.center,
                    color: Colors.black12,
                    child: const Icon(Icons.image_not_supported_outlined,
                        color: Colors.black38)),
              )
            : Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  // 微信风：自己=嫩绿，对方=白
                  color: mine ? const Color(0xFF95EC69) : Colors.white,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: _linkifyText('${m['text'] ?? ''}', Colors.black87),
              );
        // 微信风：对方头像在左、自己头像在右，气泡贴着头像。
        final avatar = GestureDetector(
          onTap: (onProfile != null && '${m['from'] ?? ''}'.isNotEmpty)
              ? () => onProfile!('${m['from']}')
              : null,
          child: CircleAvatar(
            radius: 18,
            backgroundColor: mine ? const Color(0xFF07C160) : Colors.black26,
            child: Icon(mine ? Icons.person : Icons.person_outline,
                size: 20, color: Colors.white),
          ),
        );
        final reactChips = _reactionChips(m);
        final edited = m['edited'] == true;
        final bubbleCol = Column(
          crossAxisAlignment:
              mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (group && !mine)
              Padding(
                padding: const EdgeInsets.only(left: 2, bottom: 2),
                child: GestureDetector(
                  onTap: (onProfile != null && '${m['from'] ?? ''}'.isNotEmpty)
                      ? () => onProfile!('${m['from']}')
                      : null,
                  child: Text('${m['from_nick'] ?? ''}',
                      style: const TextStyle(
                          fontSize: 11, color: Colors.black45)),
                ),
              ),
            GestureDetector(
              onLongPress: () => _msgActions(context, m),
              // 双击对方文字气泡=拍一拍发送者；卡片/红包/视频/表情包/开播提醒自带展示，不抢手势。
              onDoubleTap: (!mine &&
                      onPat != null &&
                      !isPacket &&
                      !isCard &&
                      !isVideo &&
                      !isSticker &&
                      !isLiveAlert)
                  ? () => onPat!(m)
                  : null,
              child: ConstrainedBox(
                  constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.64),
                  child: bubble),
            ),
            if (edited)
              const Padding(
                padding: EdgeInsets.only(top: 2),
                child: Text('已编辑',
                    style: TextStyle(
                        fontSize: 10,
                        color: Colors.black38,
                        fontStyle: FontStyle.italic)),
              ),
            if (reactChips != null) reactChips,
          ],
        );
        final rowChildren = mine
            ? [Flexible(child: bubbleCol), const SizedBox(width: 8), avatar]
            : [avatar, const SizedBox(width: 8), Flexible(child: bubbleCol)];
        // 多选模式：气泡前加勾选框，点击整行(不止勾选框)都能勾选，长按/双击/卡片跳转等手势暂时屏蔽。
        final rowInner = Row(
          mainAxisAlignment:
              mine ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: selectionMode
              ? [
                  Padding(
                    padding: const EdgeInsets.only(right: 4, top: 14),
                    child: Checkbox(
                      value: selectedMids.contains(mid),
                      onChanged: mid.isEmpty
                          ? null
                          : (_) => onToggleSelect?.call(mid),
                    ),
                  ),
                  ...rowChildren,
                ]
              : rowChildren,
        );
        return Container(
          key: rowKey,
          color: rowBg,
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: (selectionMode && mid.isNotEmpty)
              ? GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onToggleSelect?.call(mid),
                  child: AbsorbPointer(child: rowInner),
                )
              : rowInner,
        );
      },
    );
  }
}

// ============ 个人主页 ============
class ProfilePage extends StatefulWidget {
  final String uid;
  final void Function(String id, String title) onPlayVideo;
  const ProfilePage({super.key, required this.uid, required this.onPlayVideo});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<String, dynamic>? _p;
  bool _loading = true;
  String? _myUid;

  @override
  void initState() {
    super.initState();
    PlatformService.walletUid()
        .then((u) => mounted ? setState(() => _myUid = u) : null);
    _load();
  }

  Future<void> _load() async {
    final d = await PlatformService.profile(widget.uid);
    if (mounted) setState(() {
      _p = d;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final isBot = p?['is_bot'] == true;
    final nick = '${p?['nick'] ?? ''}';
    final isSelf = _myUid != null && _myUid == widget.uid;
    final moments = (p?['moments'] as List?)?.cast<dynamic>() ?? const [];
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F2),
      appBar: AppBar(title: const Text('个人主页')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : p == null || p['ok'] != true
              ? const Center(child: Text('加载失败'))
              : ListView(children: [
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(20),
                    child: Column(children: [
                      CircleAvatar(
                          radius: 36,
                          backgroundColor: isBot
                              ? const Color(0xFFE3A93B)
                              : const Color(0xFF07C160),
                          child: Icon(isBot ? Icons.smart_toy : Icons.person,
                              color: Colors.white, size: 40)),
                      const SizedBox(height: 10),
                      Text(nick,
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text('${p['watch_title'] ?? ''}',
                          style: const TextStyle(
                              color: Color(0xFF07C160), fontSize: 13)),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _stat('${p['ach_unlocked'] ?? 0}/${p['ach_total'] ?? 0}',
                              '成就'),
                          _stat('${p['moment_count'] ?? 0}', '动态'),
                          _stat('${p['following_count'] ?? 0}', '关注'),
                          _stat('${p['streak'] ?? 0}', '连签'),
                          if (p['balance'] != null)
                            _stat('${p['balance']}', '兑换币'),
                        ]),
                  ),
                  if (!isSelf && !isBot)
                    Padding(
                      padding: const EdgeInsets.all(14),
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFF07C160),
                            minimumSize: const Size.fromHeight(44)),
                        icon: const Icon(Icons.chat_bubble_outline),
                        label: const Text('发消息'),
                        onPressed: () => Navigator.of(context)
                            .pushReplacement(MaterialPageRoute<void>(
                                builder: (_) => _ChatPage(
                                    peer: widget.uid,
                                    peerNick: nick,
                                    onPlayVideo: widget.onPlayVideo))),
                      ),
                    ),
                  if (moments.isNotEmpty) ...[
                    const Padding(
                        padding: EdgeInsets.fromLTRB(16, 8, 0, 6),
                        child: Text('最近动态',
                            style: TextStyle(
                                fontWeight: FontWeight.w600))),
                    for (final m in moments)
                      Container(
                        color: Colors.white,
                        margin: const EdgeInsets.only(bottom: 1),
                        padding: const EdgeInsets.all(14),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if ('${m['text'] ?? ''}'.isNotEmpty)
                                Text('${m['text']}'),
                              if ('${m['vid'] ?? ''}'.isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: InkWell(
                                    onTap: () => widget.onPlayVideo(
                                        '${m['vid']}', '${m['title'] ?? ''}'),
                                    child: Row(children: [
                                      const Icon(Icons.play_circle_fill,
                                          color: Color(0xFF07C160)),
                                      const SizedBox(width: 6),
                                      Expanded(
                                          child: Text('${m['title'] ?? '视频'}',
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                  color: Colors.black54))),
                                    ]),
                                  ),
                                ),
                              const SizedBox(height: 4),
                              Text('❤️ ${m['likes'] ?? 0}',
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.black38)),
                            ]),
                      ),
                  ],
                  const SizedBox(height: 30),
                ]),
    );
  }

  Widget _stat(String v, String label) => Column(children: [
        Text(v,
            style:
                const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(fontSize: 12, color: Colors.black45)),
      ]);
}

class _ChatInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  final VoidCallback onRecommend;
  final VoidCallback? onTransfer; // 私聊才有转账
  final VoidCallback? onRedpacket; // 私聊才有发红包
  final VoidCallback? onCard; // 发个人名片
  final Map<String, String>? atMembers; // 群聊 @ 成员表(uid→昵称)
  final String? myUid;
  final VoidCallback? onMore; // 群聊「+」更多工具(投票/接龙/一起看)
  final VoidCallback? onSticker; // 表情包面板(我的收藏/精品表情)
  final bool blocked; // 私聊：我已拉黑对方 -> 隐藏输入框和发送按钮，只显示提示文字
  const _ChatInput(
      {required this.controller,
      required this.onSend,
      required this.onRecommend,
      this.onTransfer,
      this.onRedpacket,
      this.onCard,
      this.atMembers,
      this.myUid,
      this.onMore,
      this.onSticker,
      this.blocked = false});

  // 群聊输入 @ 时弹成员表；选中把「@昵称 」插进输入框。
  void _showAtPicker(BuildContext context) {
    final members = atMembers;
    if (members == null || members.isEmpty) return;
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const Padding(
              padding: EdgeInsets.all(14),
              child: Text('选择要 @ 的人',
                  style: TextStyle(fontWeight: FontWeight.w600))),
          for (final e in members.entries)
            if (e.key != myUid)
              ListTile(
                dense: true,
                leading: CircleAvatar(
                    radius: 16,
                    backgroundColor: e.key.startsWith('bot')
                        ? const Color(0xFFE3A93B)
                        : const Color(0xFF07C160),
                    child: Icon(
                        e.key.startsWith('bot')
                            ? Icons.smart_toy
                            : Icons.person,
                        color: Colors.white,
                        size: 18)),
                title: Text(e.value),
                onTap: () {
                  Navigator.pop(ctx);
                  _insertAt(e.value);
                },
              ),
        ]),
      ),
    );
  }

  void _insertAt(String nick) {
    var t = controller.text;
    if (!t.endsWith('@')) {
      if (t.isNotEmpty && !t.endsWith(' ')) t += ' '; // 按钮触发时补空格分隔
      t += '@';
    }
    controller.text = '$t$nick ';
    controller.selection = TextSelection.fromPosition(
        TextPosition(offset: controller.text.length));
  }

  @override
  Widget build(BuildContext context) {
    if (blocked) {
      // 已拉黑对方：不给任何发送入口，仅提示。
      return Container(
        color: const Color(0xFFF7F7F7),
        child: const SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 14),
            child: Center(
              child: Text('你已拉黑对方，无法发送消息',
                  style: TextStyle(color: Colors.black45, fontSize: 13)),
            ),
          ),
        ),
      );
    }
    return Container(
      color: const Color(0xFFF7F7F7), // 微信输入栏底色
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 6, 6, 6),
          child: Row(children: [
            IconButton(
              icon: const Icon(Icons.video_library_outlined,
                  color: Colors.black54),
              tooltip: '推荐视频',
              onPressed: onRecommend,
            ),
            if (onTransfer != null)
              IconButton(
                icon: const Icon(Icons.paid_outlined, color: Colors.black54),
                tooltip: '转账兑换币',
                onPressed: onTransfer,
              ),
            if (onRedpacket != null)
              IconButton(
                icon: const Text('🧧', style: TextStyle(fontSize: 20)),
                tooltip: '发红包',
                onPressed: onRedpacket,
              ),
            if (onCard != null)
              IconButton(
                icon: const Icon(Icons.contact_page_outlined,
                    color: Colors.black54),
                tooltip: '发名片',
                onPressed: onCard,
              ),
            if (onSticker != null)
              IconButton(
                icon: const Icon(Icons.emoji_emotions_outlined,
                    color: Colors.black54),
                tooltip: '表情包',
                onPressed: onSticker,
              ),
            if (atMembers != null && atMembers!.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.alternate_email, color: Colors.black54),
                tooltip: '@成员',
                onPressed: () => _showAtPicker(context),
              ),
            if (onMore != null)
              IconButton(
                icon: const Icon(Icons.add_circle_outline,
                    color: Colors.black54),
                tooltip: '投票/接龙/一起看',
                onPressed: onMore,
              ),
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: '说点什么…',
                  filled: true,
                  fillColor: Colors.white,
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(6),
                      borderSide: BorderSide.none),
                ),
                onChanged: atMembers == null
                    ? null
                    : (v) {
                        // 仅在「行首或空格后刚输入 @」时弹，避免编辑/删除到 @ 结尾时反复弹
                        if (v.endsWith('@') &&
                            (v.length == 1 ||
                                ' \n\t'.contains(v[v.length - 2]))) {
                          _showAtPicker(context);
                        }
                      },
                onSubmitted: (_) => onSend(),
              ),
            ),
            const SizedBox(width: 6),
            FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF07C160),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  minimumSize: const Size(0, 40)),
              onPressed: onSend,
              child: const Text('发送'),
            ),
          ]),
        ),
      ),
    );
  }
}

/// 选人（通讯录）。返回 {uid,nick} 或 null。
Future<Map<String, dynamic>?> _pickUser(BuildContext context) {
  return showModalBottomSheet<Map<String, dynamic>>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _UserPicker(),
  );
}

class _UserPicker extends StatefulWidget {
  const _UserPicker();
  @override
  State<_UserPicker> createState() => _UserPickerState();
}

class _UserPickerState extends State<_UserPicker> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load('');
  }

  Future<void> _load(String q) async {
    final u = await PlatformService.users(q: q);
    if (mounted) setState(() {
      _users = u;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      builder: (_, sc) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
              hintText: '搜索昵称…',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: _load,
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _users.isEmpty
                  ? const Center(
                      child: Text('没有找到用户（对方需先设昵称）',
                          style: TextStyle(color: Colors.black38)))
                  : ListView.builder(
                      controller: sc,
                      itemCount: _users.length,
                      itemBuilder: (_, i) {
                        final u = _users[i];
                        return ListTile(
                          leading:
                              const CircleAvatar(child: Icon(Icons.person)),
                          title: Text('${u['nick'] ?? ''}'),
                          onTap: () => Navigator.pop(context, u),
                        );
                      },
                    ),
        ),
      ]),
    );
  }
}

/// 选视频（推荐用）。返回 {id,title} 或 null。
Future<Map<String, dynamic>?> _pickVideo(BuildContext context) {
  return showModalBottomSheet<Map<String, dynamic>>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _VideoPicker(),
  );
}

class _VideoPicker extends StatefulWidget {
  const _VideoPicker();
  @override
  State<_VideoPicker> createState() => _VideoPickerState();
}

class _VideoPickerState extends State<_VideoPicker> {
  List<PlatformVideo> _all = [];
  String _q = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    PlatformService().list().then((v) {
      if (mounted) setState(() {
        _all = v;
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final list = _q.isEmpty
        ? _all
        : _all
            .where((v) => v.title.toLowerCase().contains(_q.toLowerCase()))
            .toList();
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      builder: (_, sc) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
              hintText: '搜索要推荐的平台视频…',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: (v) => setState(() => _q = v),
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  controller: sc,
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final v = list[i];
                    return ListTile(
                      leading: const Icon(Icons.play_circle_outline),
                      title: Text(v.title,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${v.uploader} · ▶ ${v.views}'),
                      onTap: () =>
                          Navigator.pop(context, {'id': v.id, 'title': v.title}),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

// 表情面板：分"我的收藏"/"精品表情"两个 tab。点一个表情即返回 {id,cost,name}(cost=0 表示免费)。
// "我的收藏"网格首位是"+"上传入口：选图片/GIF -> 上传服务器 -> 自动进收藏并刷新列表。
Future<Map<String, dynamic>?> _pickSticker(BuildContext context) {
  return showModalBottomSheet<Map<String, dynamic>>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _StickerPicker(),
  );
}

class _StickerPicker extends StatefulWidget {
  const _StickerPicker();
  @override
  State<_StickerPicker> createState() => _StickerPickerState();
}

class _StickerPickerState extends State<_StickerPicker> {
  bool _loading = true;
  bool _uploading = false;
  int _tab = 0; // 0=我的收藏 1=精品表情
  List<Map<String, dynamic>> _mine = [];
  List<Map<String, dynamic>> _premium = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final d = await PlatformService.stickerList();
    if (!mounted) return;
    setState(() {
      _mine = ((d?['my'] as List?) ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      _premium = ((d?['premium'] as List?) ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      _loading = false;
    });
  }

  Future<void> _upload() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    final path = r?.files.single.path;
    if (path == null || !mounted) return;
    setState(() => _uploading = true);
    final ext = path.contains('.') ? path.split('.').last.toLowerCase() : 'gif';
    final bytes = await File(path).readAsBytes();
    final d = await PlatformService.stickerUpload(bytes, ext);
    if (!mounted) return;
    if (d != null && d['ok'] == true) {
      await _load();
    } else {
      setState(() => _uploading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('上传失败，请检查网络后重试')));
    }
  }

  Future<void> _remove(String id) async {
    await PlatformService.stickerRemove(id);
    if (mounted) await _load();
  }

  Widget _thumb(String url) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(
          _fullMediaUrl(url),
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
              color: Colors.black12,
              alignment: Alignment.center,
              child: const Icon(Icons.broken_image_outlined,
                  color: Colors.black38)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.55,
      minChildSize: 0.35,
      maxChildSize: 0.85,
      builder: (_, sc) => SafeArea(
        child: Column(children: [
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            ChoiceChip(
                label: const Text('我的收藏'),
                selected: _tab == 0,
                onSelected: (_) => setState(() => _tab = 0)),
            const SizedBox(width: 10),
            ChoiceChip(
                label: const Text('精品表情'),
                selected: _tab == 1,
                onSelected: (_) => setState(() => _tab = 1)),
          ]),
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text('长按"我的收藏"里的表情可移除；精品表情发送会消耗兑换币',
                style: TextStyle(fontSize: 11, color: Colors.black45)),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : GridView.builder(
                    controller: sc,
                    padding: const EdgeInsets.all(12),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 4,
                            mainAxisSpacing: 10,
                            crossAxisSpacing: 10),
                    itemCount:
                        _tab == 0 ? _mine.length + 1 : _premium.length,
                    itemBuilder: (_, i) {
                      if (_tab == 0) {
                        if (i == 0) {
                          return InkWell(
                            onTap: _uploading ? null : _upload,
                            child: Container(
                              decoration: BoxDecoration(
                                  color: const Color(0xFFF0F0F0),
                                  borderRadius: BorderRadius.circular(8)),
                              alignment: Alignment.center,
                              child: _uploading
                                  ? const SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                          strokeWidth: 2))
                                  : const Icon(Icons.add,
                                      color: Colors.black45),
                            ),
                          );
                        }
                        final s = _mine[i - 1];
                        return GestureDetector(
                          onTap: () => Navigator.pop(
                              context, {'id': s['id'], 'cost': 0}),
                          onLongPress: () => _remove('${s['id']}'),
                          child: _thumb('${s['url'] ?? ''}'),
                        );
                      }
                      final s = _premium[i];
                      final cost = (s['cost'] as num?)?.toInt() ?? 0;
                      return GestureDetector(
                        onTap: () => Navigator.pop(context,
                            {'id': s['id'], 'cost': cost, 'name': s['name']}),
                        child: Column(children: [
                          Expanded(child: _thumb('${s['url'] ?? ''}')),
                          const SizedBox(height: 2),
                          Text('🪙$cost',
                              style: const TextStyle(
                                  fontSize: 10, color: Colors.black54)),
                        ]),
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}

Future<bool> _confirm(BuildContext context, String title, String body) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('确定')),
      ],
    ),
  );
  return r == true;
}

// ============ 朋友圈(动态) ============
class MomentsPage extends StatefulWidget {
  final void Function(String id, String title) onPlayVideo;
  const MomentsPage({super.key, required this.onPlayVideo});
  @override
  State<MomentsPage> createState() => _MomentsPageState();
}

class _MomentsPageState extends State<MomentsPage> {
  bool _loading = true;
  List<Map<String, dynamic>> _list = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final m = await PlatformService.moments();
    if (mounted) setState(() {
      _list = m;
      _loading = false;
    });
  }

  Future<void> _compose() async {
    final ctrl = TextEditingController();
    Map<String, dynamic>? vid;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('发动态'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
                controller: ctrl,
                autofocus: true,
                maxLines: 4,
                maxLength: 500,
                decoration: const InputDecoration(hintText: '这一刻的想法…')),
            if (vid != null)
              ListTile(
                  dense: true,
                  leading: const Icon(Icons.play_circle, color: Color(0xFFF26B21)),
                  title: Text('${vid!['title']}',
                      maxLines: 1, overflow: TextOverflow.ellipsis)),
            TextButton.icon(
              icon: const Icon(Icons.video_library_outlined, size: 18),
              label: Text(vid == null ? '附带一个视频' : '换个视频'),
              onPressed: () async {
                final v = await _pickVideo(ctx);
                if (v != null) setD(() => vid = v);
              },
            ),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('发布')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final text = ctrl.text.trim();
    if (text.isEmpty && vid == null) return;
    final sent = await PlatformService.momentPost(text,
        vid: vid?['id'] as String? ?? '', title: vid?['title'] as String? ?? '');
    if (sent) _load();
  }

  String _ago(int ts) {
    final d = DateTime.now()
        .difference(DateTime.fromMillisecondsSinceEpoch(ts * 1000));
    if (d.inMinutes < 1) return '刚刚';
    if (d.inHours < 1) return '${d.inMinutes}分钟前';
    if (d.inDays < 1) return '${d.inHours}小时前';
    return '${d.inDays}天前';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('朋友圈')),
      floatingActionButton: FloatingActionButton(
        onPressed: _compose,
        tooltip: '发动态',
        child: const Icon(Icons.add_a_photo_outlined),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _list.isEmpty
              ? const Center(
                  child: Text('还没有动态，发第一条吧~',
                      style: TextStyle(color: Colors.black38)))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    itemCount: _list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) => _MomentTile(
                        m: _list[i],
                        ago: _ago,
                        onPlayVideo: widget.onPlayVideo,
                        onChanged: _load),
                  ),
                ),
    );
  }
}

class _MomentTile extends StatefulWidget {
  final Map<String, dynamic> m;
  final String Function(int) ago;
  final void Function(String id, String title) onPlayVideo;
  final VoidCallback onChanged;
  const _MomentTile(
      {required this.m,
      required this.ago,
      required this.onPlayVideo,
      required this.onChanged});
  @override
  State<_MomentTile> createState() => _MomentTileState();
}

class _MomentTileState extends State<_MomentTile> {
  late bool _liked = widget.m['liked'] == true;
  late int _likes = (widget.m['likes'] as num?)?.toInt() ?? 0;
  late List<dynamic> _comments = (widget.m['comments'] as List?) ?? [];

  Future<void> _like() async {
    final d = await PlatformService.momentLike('${widget.m['id']}');
    if (d != null && d['ok'] == true && mounted) {
      setState(() {
        _liked = d['liked'] == true;
        _likes = (d['likes'] as num).toInt();
      });
    }
  }

  Future<void> _comment() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('评论'),
        content: TextField(controller: ctrl, autofocus: true, maxLength: 200),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('发送')),
        ],
      ),
    );
    if (ok != true) return;
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    if (await PlatformService.momentComment('${widget.m['id']}', t)) {
      widget.onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final m = widget.m;
    final vid = '${m['vid'] ?? ''}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
              radius: 18,
              backgroundColor: cs.primary,
              child: const Icon(Icons.person, color: Colors.white, size: 20)),
          const SizedBox(width: 10),
          Text('${m['nick'] ?? ''}',
              style: const TextStyle(fontWeight: FontWeight.w600)),
          const Spacer(),
          Text(widget.ago((m['ts'] as num?)?.toInt() ?? 0),
              style: const TextStyle(fontSize: 11, color: Colors.black38)),
        ]),
        if ('${m['text'] ?? ''}'.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 46, top: 4),
            child: Text('${m['text']}'),
          ),
        if (vid.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 46, top: 6),
            child: InkWell(
              onTap: () => widget.onPlayVideo(vid, '${m['title'] ?? '视频'}'),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(6)),
                child: Row(children: [
                  Icon(Icons.play_circle_fill, color: cs.primary),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text('${m['title'] ?? '视频'}',
                          maxLines: 1, overflow: TextOverflow.ellipsis)),
                ]),
              ),
            ),
          ),
        Padding(
          padding: const EdgeInsets.only(left: 40, top: 4),
          child: Row(children: [
            TextButton.icon(
              onPressed: _like,
              icon: Icon(_liked ? Icons.favorite : Icons.favorite_border,
                  size: 18, color: _liked ? Colors.red : Colors.black45),
              label: Text('$_likes',
                  style: const TextStyle(color: Colors.black54)),
            ),
            TextButton.icon(
              onPressed: _comment,
              icon: const Icon(Icons.mode_comment_outlined,
                  size: 18, color: Colors.black45),
              label: Text('${_comments.length}',
                  style: const TextStyle(color: Colors.black54)),
            ),
          ]),
        ),
        if (_comments.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(left: 46),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.04),
                borderRadius: BorderRadius.circular(6)),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final c in _comments)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: RichText(
                        text: TextSpan(
                            style: const TextStyle(
                                color: Colors.black87, fontSize: 13),
                            children: [
                              TextSpan(
                                  text: '${c['nick'] ?? ''}：',
                                  style: TextStyle(
                                      color: cs.primary,
                                      fontWeight: FontWeight.w600)),
                              TextSpan(text: '${c['text'] ?? ''}'),
                            ]),
                      ),
                    ),
                ]),
          ),
      ]),
    );
  }
}

// ============ 机器人管理 ============
class BotPage extends StatefulWidget {
  const BotPage({super.key});
  @override
  State<BotPage> createState() => _BotPageState();
}

class _BotPageState extends State<BotPage> {
  bool _loading = true;
  List<Map<String, dynamic>> _bots = [];
  List<Map<String, dynamic>> _groups = [];
  List<Map<String, dynamic>> _users = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final b = await PlatformService.botList();
    final g = await PlatformService.groupList();
    final u = await PlatformService.users();
    if (mounted) setState(() {
      _bots = b;
      _groups = g;
      _users = u.where((x) => !'${x['uid']}'.startsWith('bot')).toList();
      _loading = false;
    });
  }

  // 10 个事件触发规则：[key, 中文名, 默认回复]
  static const List<List<String>> _evtRules = [
    ['app_open', '打开软件', '欢迎回来！今天也要开心鸭~'],
    ['sign', '每日签到', '签到成功，坚持就是胜利！'],
    ['comeback', '久别回归', '好久不见，可想你了~'],
    ['low_balance', '余额告急', '兑换币不多啦，记得签到/看视频赚币~'],
    ['watch', '观影达标', '观影达人！又解锁一个里程碑👏'],
    ['moment', '发了朋友圈', '动态发布成功，已帮你点亮✨'],
    ['got_packet', '收到红包/转账', '到账啦，恭喜发财🧧'],
    ['follow', '关注了人', '关注成功，又多了个好友~'],
    ['achievement', '解锁成就', '叮！解锁新成就，太强了🏆'],
    ['night', '深夜关怀', '夜深了，注意休息哦🌙'],
  ];

  Future<void> _create() async {
    final nameCtrl = TextEditingController();
    final wordCtrl = TextEditingController();
    final textCtrl = TextEditingController(text: '你好呀，我是机器人~');
    final everyCtrl = TextEditingController(text: '0');
    final evtCtrls = {
      for (final e in _evtRules) e[0]: TextEditingController(text: e[2])
    };
    final evtOn = <String>{};
    String kind = 'text';
    String? target;
    Map<String, dynamic>? vid;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('创建机器人'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                  controller: nameCtrl,
                  maxLength: 20,
                  decoration: const InputDecoration(labelText: '机器人名字')),
              TextField(
                  controller: wordCtrl,
                  maxLength: 40,
                  decoration: const InputDecoration(
                      labelText: '触发词（留空=任何消息都回）')),
              const SizedBox(height: 8),
              Row(children: [
                const Text('回复：'),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: kind,
                  items: const [
                    DropdownMenuItem(value: 'text', child: Text('文字')),
                    DropdownMenuItem(value: 'video', child: Text('视频')),
                    DropdownMenuItem(value: 'coupon', child: Text('送优惠券')),
                  ],
                  onChanged: (v) => setD(() => kind = v ?? 'text'),
                ),
              ]),
              TextField(
                  controller: textCtrl,
                  maxLength: 200,
                  decoration: const InputDecoration(labelText: '回复文字')),
              if (kind == 'video')
                TextButton.icon(
                  icon: const Icon(Icons.video_library_outlined, size: 18),
                  label: Text(vid == null ? '选个视频' : '已选：${vid!['title']}'),
                  onPressed: () async {
                    final v = await _pickVideo(ctx);
                    if (v != null) setD(() => vid = v);
                  },
                ),
              const Divider(),
              const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('⏰ 定时发送（选填）',
                      style: TextStyle(fontWeight: FontWeight.w600))),
              TextField(
                  controller: everyCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: '每几分钟发一次（0=不定时）')),
              if (_groups.isEmpty && _users.isEmpty)
                const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('（先建群或加联系人，定时机器人发给他们）',
                        style: TextStyle(fontSize: 12, color: Colors.black45)))
              else
                Row(children: [
                  const Text('发给：'),
                  const SizedBox(width: 8),
                  Expanded(
                    child: DropdownButton<String>(
                      isExpanded: true,
                      value: target,
                      hint: const Text('选群或用户'),
                      items: [
                        for (final g in _groups)
                          DropdownMenuItem(
                              value: g['gid'] as String,
                              child: Text('👥 ${g['name']}',
                                  overflow: TextOverflow.ellipsis)),
                        for (final u in _users)
                          DropdownMenuItem(
                              value: u['uid'] as String,
                              child: Text('👤 ${u['nick']}',
                                  overflow: TextOverflow.ellipsis)),
                      ],
                      onChanged: (v) => setD(() => target = v),
                    ),
                  ),
                ]),
              const Divider(),
              const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('🔔 事件触发（选填，满足规则机器人就私信你）',
                      style: TextStyle(fontWeight: FontWeight.w600))),
              for (final e in _evtRules) ...[
                Row(children: [
                  Checkbox(
                    visualDensity: VisualDensity.compact,
                    value: evtOn.contains(e[0]),
                    onChanged: (v) => setD(() =>
                        v == true ? evtOn.add(e[0]) : evtOn.remove(e[0])),
                  ),
                  Expanded(child: Text(e[1])),
                ]),
                if (evtOn.contains(e[0]))
                  Padding(
                    padding: const EdgeInsets.only(left: 12, bottom: 6),
                    child: TextField(
                        controller: evtCtrls[e[0]],
                        maxLength: 100,
                        style: const TextStyle(fontSize: 13),
                        decoration: const InputDecoration(
                            isDense: true,
                            counterText: '',
                            labelText: '机器人发的内容')),
                  ),
              ],
            ]),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('创建')),
          ],
        ),
      ),
    );
    // 先把值读出来，再统一释放控制器(含 10 个事件控制器)，避免泄漏。
    final name = nameCtrl.text.trim();
    final word = wordCtrl.text.trim();
    final replyText = textCtrl.text.trim();
    final every = int.tryParse(everyCtrl.text.trim()) ?? 0;
    final events = <String, String>{};
    for (final e in _evtRules) {
      if (evtOn.contains(e[0])) {
        final t = evtCtrls[e[0]]!.text.trim();
        if (t.isNotEmpty) events[e[0]] = t;
      }
    }
    for (final c in [nameCtrl, wordCtrl, textCtrl, everyCtrl, ...evtCtrls.values]) {
      c.dispose();
    }
    if (ok != true || name.isEmpty) return;
    final d = await PlatformService.botCreate(
      name: name,
      word: word,
      kind: kind,
      text: replyText,
      vid: vid?['id'] as String? ?? '',
      title: vid?['title'] as String? ?? '',
      item: kind == 'coupon' ? 'coupon_10' : '',
      scheduleMin: (every > 0 && target != null) ? every : 0,
      target: target ?? '',
      events: events,
    );
    if (d != null && d['ok'] == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('我的机器人')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.smart_toy_outlined),
        label: const Text('建机器人'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                    '机器人会出现在通讯录里。在「消息→找人」搜机器人名字即可和它聊天，命中触发词就自动回复。',
                    style: TextStyle(fontSize: 12, color: Colors.black54)),
              ),
              Expanded(
                child: _bots.isEmpty
                    ? const Center(
                        child: Text('还没有机器人，点下面建一个~',
                            style: TextStyle(color: Colors.black38)))
                    : ListView.separated(
                        itemCount: _bots.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final b = _bots[i];
                          final k = '${b['kind']}';
                          return ListTile(
                            leading: const CircleAvatar(
                                backgroundColor: Color(0xFF07C160),
                                child: Icon(Icons.smart_toy,
                                    color: Colors.white)),
                            title: Text('🤖${b['name']}'),
                            subtitle: Text(
                                '触发词：${(b['word'] as String).isEmpty ? '任何消息' : b['word']} → ${k == 'video' ? '回视频' : k == 'coupon' ? '送券' : '回文字'}'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline,
                                  color: Colors.red),
                              onPressed: () async {
                                if (await PlatformService.botDelete(
                                    '${b['id']}')) _load();
                              },
                            ),
                          );
                        },
                      ),
              ),
            ]),
    );
  }
}
